using LocmiTimeCard.Application.Models;

namespace LocmiTimeCard.Application.Contracts;

public interface IAttendanceService
{
    Task<LoginResponse?> LoginAsync(LoginRequest request);
    SessionIdentityDto GetSession(string? token);
    void Logout(string? token);
    Task<EmployeeDashboardDto> GetEmployeeDashboardAsync(string employeeEmail, string? forDate = null);
    Task<EmployeeDashboardDto?> ApplyEmployeeActionAsync(string employeeEmail, string action);
    Task<AdminWorkforceDto> GetAdminWorkforceAsync();
    Task<AdminEmployeeDetailDto> GetAdminEmployeeDetailAsync(string employeeEmail, string? forDate = null);
    Task<(bool Ok, string EmployeeEmail, string? Error)> CreateEmployeeAsync(CreateEmployeeRequest request);
    Task<(bool Ok, string EmployeeEmail, string? Error)> UpdateEmployeeAsync(string employeeEmail, CreateEmployeeRequest request);
    Task<(bool Ok, string? Error)> DeactivateEmployeeAsync(string employeeEmail);
    Task<AdminAdjustmentResponse> ApplyAdminAdjustmentAsync(AdminAdjustmentRequest request);
    Task<UploadStaffImageResponse> SaveStaffImageAsync(UploadStaffImageRequest request, string webRootPath, string? basePath = null);
    Task<(bool Ok, string ProfileImageUrl, string? Error)> UpdateEmployeeProfileImageAsync(string employeeEmail, string profileImageUrl);
    Task<(string FileName, string ContentType, string Csv)> ExportPayrollCsvAsync(string? startDate, string? endDate);
}
