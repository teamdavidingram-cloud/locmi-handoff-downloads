using LocmiTimeCard.Domain;

namespace LocmiTimeCard.Application.Models;

public record SessionIdentityDto(string? Role, string? Email);

public record LoginRequest(string Email, string Role, string Password);
public record LoginResponse(bool Ok, string Token, string Role, string Email);

public record TimelineEventDto(string Id, string EventType, string OccurredAt, string Label, string Detail, string Icon);

public record EmployeeDashboardDto(
    EmployeeCardDto Employee,
    string SelectedDate,
    List<string> Actions,
    List<TimelineEventDto> Timeline,
    TotalsDto Totals,
    string LastActionNote);

public record EmployeeCardDto(
    string Id,
    string Name,
    string Role,
    string Department,
    string Status,
    string Shift,
    string MonthHours,
    string HourlyRate,
    string? ProfileImageUrl);

public record TotalsDto(string Today, string Break);

public record WorkforceEmployeeDto(
    string Name,
    string Status,
    string Context,
    string? ProfileImageUrl,
    bool Active,
    string Email,
    string Department,
    string Title,
    string HourlyRate,
    string ShiftStart,
    string ShiftEnd);

public record AdminAdjustmentHistoryItemDto(string EmployeeName, string Reason, string AdminEmail, string CreatedAt);

public record AdminWorkforceDto(
    SummaryDto Summary,
    List<WorkforceEmployeeDto> Employees,
    List<AdminAdjustmentHistoryItemDto> RecentAdjustments);

public record SummaryDto(int ClockedIn, int OnBreak, int Alerts);

public record AdminEmployeeDetailDto(
    AdminEmployeeCardDto Employee,
    List<TimelineEventDto> Timeline,
    List<AdminAdjustmentHistoryItemDto> RecentAdjustments);

public record AdminEmployeeCardDto(
    string Name,
    string Email,
    string Department,
    string Role,
    string Status,
    string Shift,
    string HourlyRate,
    string? ProfileImageUrl,
    TotalsDto Totals);

public record CreateEmployeeRequest(
    string FirstName,
    string LastName,
    string Department,
    string Title,
    decimal HourlyRate,
    string ShiftStart,
    string ShiftEnd,
    string? ProfileImageUrl);

public record AdminAdjustmentRequest(string EmployeeEmail, string EventType, string Reason, string? Note);

public record AdminAdjustmentResponse(bool Ok, string EmployeeName, string Status, TotalsDto Totals, AuditDto Audit);
public record AuditDto(string Reason, string AdminEmail);

public record UploadStaffImageRequest(string FileName, string? MimeType, string DataBase64);
public record UploadStaffImageResponse(bool Ok, string ImageUrl);
public record UpdateProfileImageRequest(string ProfileImageUrl);
