# LOCMI Time Card .NET Handover

This folder contains the working .NET 8 rewrite of the LOCMI Time Card project.

## Source Project

- Original project: `/home/ingramlaw/projects/locmi-time-card`
- Original stack: React + TypeScript frontend, Express + TypeScript API, Prisma, PostgreSQL

## Rewrite Workspace

- Handover root: `/home/ingramlaw/projects/lock-project/locmi-time-card-dotnet`
- Solution: `LocmiTimeCard.sln`

Projects inside the solution:
- `LocmiTimeCard.Api` → ASP.NET Core API and hosted static web delivery
- `LocmiTimeCard.Web` → Blazor WebAssembly client
- `LocmiTimeCard.Domain` → entities and enums
- `LocmiTimeCard.Application` → DTOs and contracts
- `LocmiTimeCard.Infrastructure` → EF Core persistence and service implementation

## Current Working Scope

This rewrite now includes working .NET implementations for:

- login/session handling
- employee dashboard
- clock in / break start / break end / clock out
- admin dashboard
- admin employee attendance detail
- admin attendance adjustments with audit trail
- employee create / update / deactivate
- payroll CSV export
- staff profile image upload + attachment flow
- SQLite-backed persistence via EF Core migrations
- hosted Blazor UI served by the .NET API project

## Recommended Run Mode

The cleanest current handoff mode is to run the API project, which also hosts the built Blazor client.

### Single-host run

```bash
cd /home/ingramlaw/projects/lock-project/locmi-time-card-dotnet
dotnet run --project LocmiTimeCard.Api/LocmiTimeCard.Api.csproj --urls http://127.0.0.1:5099
```

Then open:

- `http://127.0.0.1:5099`

Notes:
- SQLite database file is created under `LocmiTimeCard.Api/App_Data/`
- EF Core migrations are applied automatically on startup
- API routes remain available under `/api/...`

## Alternative Development Run Mode

If a developer wants to run the Blazor client separately during UI work:

### 1. Start the API

```bash
cd /home/ingramlaw/projects/lock-project/locmi-time-card-dotnet
dotnet run --project LocmiTimeCard.Api/LocmiTimeCard.Api.csproj --urls http://127.0.0.1:5099
```

### 2. Start the web client separately

```bash
cd /home/ingramlaw/projects/lock-project/locmi-time-card-dotnet
dotnet run --project LocmiTimeCard.Web/LocmiTimeCard.Web.csproj --urls http://127.0.0.1:5100
```

Then open:

- `http://127.0.0.1:5100`

In development, the Blazor client is configured to call the API at `http://127.0.0.1:5099`.

## Demo Credentials

### Admin
- Email: `admin@locmi.local`
- Password: `admin123`

### Employee
- Email: `maria.santos@locmi.local`
- Password: `maria123`

Additional seeded employees:
- `james.lee@locmi.local`
- `anika.patel@locmi.local`
- `ruth.garcia@locmi.local`

## Build Verification

Latest verified command:

```bash
dotnet build LocmiTimeCard.sln
```

Verified result at last pass:

- Build succeeded
- `0 Warning(s)`
- `0 Error(s)`

## Important Files

### API host
- `LocmiTimeCard.Api/Program.cs`
- `LocmiTimeCard.Api/Controllers/AuthController.cs`
- `LocmiTimeCard.Api/Controllers/EmployeeController.cs`
- `LocmiTimeCard.Api/Controllers/AdminController.cs`
- `LocmiTimeCard.Api/Controllers/UploadsController.cs`

### Domain / persistence
- `LocmiTimeCard.Domain/Entities.cs`
- `LocmiTimeCard.Domain/Enums.cs`
- `LocmiTimeCard.Infrastructure/AttendanceService.cs`
- `LocmiTimeCard.Infrastructure/Persistence/LocmiTimeCardDbContext.cs`
- `LocmiTimeCard.Infrastructure/Persistence/Migrations/`

### Web client
- `LocmiTimeCard.Web/Pages/Index.razor`
- `LocmiTimeCard.Web/Components/EmployeeDashboard.razor`
- `LocmiTimeCard.Web/Components/AdminDashboard.razor`
- `LocmiTimeCard.Web/Services/ApiClient.cs`
- `LocmiTimeCard.Web/Services/AuthState.cs`
- `LocmiTimeCard.Web/wwwroot/css/app.css`

## Publish & Service Notes

See also:

- `deploy/PUBLISH.md`
- `deploy/locmi-time-card-dotnet.service`

## Handover Notes

This is now a real working .NET handoff base with a cleaner deploy story than before.

Remaining gaps worth finishing before calling it fully complete:

- strengthen route/session protection in the web client
- improve dedicated employee detail routing/UI polish
- add production-grade service/publish instructions
- decide whether the current in-memory session token approach should be replaced with a more durable auth/session model

## Recommended Next Step

The next pass should focus on production packaging and deployment instructions, not another rewrite.

## Recent Conversion Commits

- `6c7592d` `Implement initial LOCMI Time Card .NET API flows`
- `f168069` `Start LOCMI Time Card .NET web client`
- `fa9a989` `Expand LOCMI Time Card admin web flows`
- `370a3f7` `Polish LOCMI Time Card .NET handoff flows`
- `8fa83b1` `Document LOCMI Time Card .NET handoff runbook`
