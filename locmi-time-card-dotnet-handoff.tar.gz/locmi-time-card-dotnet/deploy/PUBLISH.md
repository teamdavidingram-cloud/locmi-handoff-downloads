# LOCMI Time Card .NET Publish & Service Notes

## Publish

From the solution root:

```bash
cd /home/ingramlaw/projects/lock-project/locmi-time-card-dotnet
dotnet publish LocmiTimeCard.Api/LocmiTimeCard.Api.csproj -c Release
```

Published output will appear under:

- `LocmiTimeCard.Api/bin/Release/net8.0/publish/`

Because the API hosts the Blazor client, publishing the API project is the main deployment artifact.

## Local production-style run

```bash
cd /home/ingramlaw/projects/lock-project/locmi-time-card-dotnet
dotnet run --project LocmiTimeCard.Api/LocmiTimeCard.Api.csproj -c Release --urls http://127.0.0.1:5099
```

## systemd service outline

A sample unit file is included here:

- `deploy/locmi-time-card-dotnet.service`

Expected approach:
1. Publish the API project in Release mode
2. Point `ExecStart` at the built `LocmiTimeCard.Api.dll`
3. Optionally place Caddy or another reverse proxy in front of `127.0.0.1:5099`

## Reverse proxy notes

The app serves both:
- web UI at `/`
- API at `/api/...`

So only one upstream is needed.

## Data location

SQLite database is created at:

- `LocmiTimeCard.Api/App_Data/locmi-time-card.db`

Back this file up if preserving attendance data matters.
