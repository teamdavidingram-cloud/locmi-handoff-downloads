namespace LocmiTimeCard.Domain;

public enum Role
{
    Employee,
    Admin
}

public enum AttendanceStatus
{
    NotClockedIn,
    ClockedIn,
    OnBreak,
    ClockedOut
}

public enum TimeEventType
{
    ClockIn,
    BreakStart,
    BreakEnd,
    ClockOut,
    Adjustment
}

public enum BreakType
{
    Paid,
    Unpaid
}
