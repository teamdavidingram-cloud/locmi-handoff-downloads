namespace LocmiTimeCard.Domain;

public class User
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Email { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public Role Role { get; set; } = Role.Employee;
    public string? PasswordHash { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public EmployeeProfile? EmployeeProfile { get; set; }
    public List<AdjustmentLog> AdjustmentLogs { get; set; } = [];
}

public class EmployeeProfile
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }
    public Guid? DepartmentId { get; set; }
    public int? HourlyRateCents { get; set; }
    public string? Title { get; set; }
    public string? DefaultShiftStart { get; set; }
    public string? DefaultShiftEnd { get; set; }
    public string? ProfileImageUrl { get; set; }
    public bool IsActive { get; set; } = true;
    public AttendanceStatus ActiveStatus { get; set; } = AttendanceStatus.NotClockedIn;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public User User { get; set; } = null!;
    public Department? Department { get; set; }
    public List<TimeEntryDay> TimeEntryDays { get; set; } = [];
    public List<DeviceLog> DeviceLogs { get; set; } = [];
}

public class Department
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public List<EmployeeProfile> Employees { get; set; } = [];
}

public class TimeEntryDay
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid EmployeeProfileId { get; set; }
    public DateTime WorkDate { get; set; }
    public AttendanceStatus Status { get; set; } = AttendanceStatus.NotClockedIn;
    public int TotalMinutesWorked { get; set; }
    public int TotalBreakMinutes { get; set; }
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public EmployeeProfile EmployeeProfile { get; set; } = null!;
    public List<TimeEvent> TimeEvents { get; set; } = [];
    public List<AdjustmentLog> AdjustmentLogs { get; set; } = [];
}

public class TimeEvent
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid TimeEntryDayId { get; set; }
    public TimeEventType EventType { get; set; }
    public BreakType? BreakType { get; set; }
    public DateTime OccurredAt { get; set; }
    public string? Note { get; set; }
    public string? DeviceLabel { get; set; }
    public string? LocationLabel { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public TimeEntryDay TimeEntryDay { get; set; } = null!;
}

public class AdjustmentLog
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid TimeEntryDayId { get; set; }
    public Guid AdminUserId { get; set; }
    public string Reason { get; set; } = string.Empty;
    public string BeforeJson { get; set; } = string.Empty;
    public string AfterJson { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public User AdminUser { get; set; } = null!;
    public TimeEntryDay TimeEntryDay { get; set; } = null!;
}

public class DeviceLog
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid EmployeeProfileId { get; set; }
    public string Label { get; set; } = string.Empty;
    public string? IpAddress { get; set; }
    public DateTime? LastSeenAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public EmployeeProfile EmployeeProfile { get; set; } = null!;
}
