using LocmiTimeCard.Application.Contracts;
using LocmiTimeCard.Infrastructure;
using LocmiTimeCard.Infrastructure.Persistence;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddResponseCompression(options =>
{
    options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(new[] { "application/octet-stream" });
});

var dataDirectory = Path.Combine(builder.Environment.ContentRootPath, "App_Data");
Directory.CreateDirectory(dataDirectory);
var connectionString = builder.Configuration.GetConnectionString("Default")
    ?? $"Data Source={Path.Combine(dataDirectory, "locmi-time-card.db")}";

builder.Services.AddDbContext<LocmiTimeCardDbContext>(options => options.UseSqlite(connectionString));
builder.Services.AddScoped<IAttendanceService, AttendanceService>();
builder.Services.AddCors(options =>
{
    options.AddPolicy("App", policy => policy
        .AllowAnyHeader()
        .AllowAnyMethod()
        .AllowAnyOrigin());
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<LocmiTimeCardDbContext>();
    db.Database.Migrate();
}

app.UseResponseCompression();
app.UseSwagger();
app.UseSwaggerUI();
app.UseBlazorFrameworkFiles();
app.UseStaticFiles();
app.UseCors("App");
app.UseAuthorization();
app.MapControllers();
app.MapFallbackToFile("index.html");
app.Run();
