using LocmiTimeCard.Application.Contracts;
using LocmiTimeCard.Application.Models;
using Microsoft.AspNetCore.Mvc;

namespace LocmiTimeCard.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController(IAttendanceService attendanceService) : ControllerBase
{
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var result = await attendanceService.LoginAsync(request);
        return result is null ? Unauthorized(new { ok = false, message = "Invalid credentials" }) : Ok(result);
    }

    [HttpGet("session")]
    public IActionResult Session()
    {
        var token = Request.Headers.Authorization.ToString().Replace("Bearer ", string.Empty);
        return Ok(attendanceService.GetSession(token));
    }

    [HttpPost("logout")]
    public IActionResult Logout()
    {
        var token = Request.Headers.Authorization.ToString().Replace("Bearer ", string.Empty);
        attendanceService.Logout(token);
        return Ok(new { ok = true });
    }
}
