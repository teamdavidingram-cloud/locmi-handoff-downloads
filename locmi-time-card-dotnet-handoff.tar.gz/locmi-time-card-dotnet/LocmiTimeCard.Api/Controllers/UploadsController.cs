using LocmiTimeCard.Api.Models;
using LocmiTimeCard.Application.Contracts;
using LocmiTimeCard.Application.Models;
using Microsoft.AspNetCore.Mvc;

namespace LocmiTimeCard.Api.Controllers;

[ApiController]
[Route("api/uploads")]
public class UploadsController(IAttendanceService attendanceService, IWebHostEnvironment environment) : ControllerBase
{
    [HttpPost("staff-image")]
    public async Task<IActionResult> UploadStaffImage([FromBody] StaffImageUploadApiRequest request)
    {
        var result = await attendanceService.SaveStaffImageAsync(
            new UploadStaffImageRequest(request.FileName, request.MimeType, request.DataBase64),
            environment.WebRootPath,
            null);
        return Ok(result);
    }

    [HttpPut("staff-image/{email}")]
    public async Task<IActionResult> AttachStaffImage(string email, [FromBody] UpdateProfileImageRequest request)
    {
        var result = await attendanceService.UpdateEmployeeProfileImageAsync(email, request.ProfileImageUrl);
        return result.Ok ? Ok(new { ok = true, profileImageUrl = result.ProfileImageUrl }) : NotFound(new { ok = false, message = result.Error });
    }
}
