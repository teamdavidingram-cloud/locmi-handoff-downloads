using LocmiTimeCard.Application.Contracts;
using LocmiTimeCard.Application.Models;
using Microsoft.AspNetCore.Mvc;

namespace LocmiTimeCard.Api.Controllers;

[ApiController]
[Route("api/admin")]
public class AdminController(IAttendanceService attendanceService) : ControllerBase
{
    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard()
    {
        return Ok(await attendanceService.GetAdminWorkforceAsync());
    }

    [HttpGet("employee/{email}")]
    public async Task<IActionResult> EmployeeDetail(string email, [FromQuery] string? date)
    {
        return Ok(await attendanceService.GetAdminEmployeeDetailAsync(email, date));
    }

    [HttpPost("employees")]
    public async Task<IActionResult> CreateEmployee([FromBody] CreateEmployeeRequest request)
    {
        var result = await attendanceService.CreateEmployeeAsync(request);
        return result.Ok ? Ok(new { ok = true, employeeEmail = result.EmployeeEmail }) : BadRequest(new { ok = false, message = result.Error });
    }

    [HttpPut("employees/{email}")]
    public async Task<IActionResult> UpdateEmployee(string email, [FromBody] CreateEmployeeRequest request)
    {
        var result = await attendanceService.UpdateEmployeeAsync(email, request);
        return result.Ok ? Ok(new { ok = true, employeeEmail = result.EmployeeEmail }) : NotFound(new { ok = false, message = result.Error });
    }

    [HttpDelete("employees/{email}")]
    public async Task<IActionResult> DeactivateEmployee(string email)
    {
        var result = await attendanceService.DeactivateEmployeeAsync(email);
        return result.Ok ? Ok(new { ok = true }) : NotFound(new { ok = false, message = result.Error });
    }

    [HttpPost("adjustments")]
    public async Task<IActionResult> Adjust([FromBody] AdminAdjustmentRequest request)
    {
        return Ok(await attendanceService.ApplyAdminAdjustmentAsync(request));
    }

    [HttpGet("payroll/export")]
    public async Task<IActionResult> Export([FromQuery] string? startDate, [FromQuery] string? endDate)
    {
        var result = await attendanceService.ExportPayrollCsvAsync(startDate, endDate);
        return File(System.Text.Encoding.UTF8.GetBytes(result.Csv), result.ContentType, result.FileName);
    }
}
