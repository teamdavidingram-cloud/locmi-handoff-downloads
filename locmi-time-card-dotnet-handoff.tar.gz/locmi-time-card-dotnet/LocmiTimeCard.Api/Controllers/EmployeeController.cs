using LocmiTimeCard.Api.Models;
using LocmiTimeCard.Application.Contracts;
using Microsoft.AspNetCore.Mvc;

namespace LocmiTimeCard.Api.Controllers;

[ApiController]
[Route("api/employee")]
public class EmployeeController(IAttendanceService attendanceService) : ControllerBase
{
    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard([FromQuery] string? employeeEmail, [FromQuery] string? date)
    {
        var dashboard = await attendanceService.GetEmployeeDashboardAsync(employeeEmail ?? string.Empty, date);
        return Ok(dashboard);
    }

    [HttpPost("action")]
    public async Task<IActionResult> Action([FromQuery] string? employeeEmail, [FromBody] ActionRequest request)
    {
        var dashboard = await attendanceService.ApplyEmployeeActionAsync(employeeEmail ?? string.Empty, request.Action);
        return dashboard is null ? BadRequest(new { ok = false, message = "Action not allowed for current status" }) : Ok(dashboard);
    }
}
