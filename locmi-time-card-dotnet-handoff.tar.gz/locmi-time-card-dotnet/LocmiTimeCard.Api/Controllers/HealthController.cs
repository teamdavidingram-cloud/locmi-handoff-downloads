using Microsoft.AspNetCore.Mvc;

namespace LocmiTimeCard.Api.Controllers;

[ApiController]
[Route("api/health")]
public class HealthController : ControllerBase
{
    [HttpGet]
    public IActionResult Get() => Ok(new { ok = true, service = "locmi-time-card-dotnet", timestamp = DateTime.UtcNow });
}
