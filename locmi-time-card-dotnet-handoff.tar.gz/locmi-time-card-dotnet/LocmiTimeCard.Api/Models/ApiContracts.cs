namespace LocmiTimeCard.Api.Models;

public record ActionRequest(string Action);
public record EmployeeQuery(string? EmployeeEmail, string? Date);
public record PayrollExportQuery(string? StartDate, string? EndDate);
public record StaffImageUploadApiRequest(string FileName, string? MimeType, string DataBase64);
