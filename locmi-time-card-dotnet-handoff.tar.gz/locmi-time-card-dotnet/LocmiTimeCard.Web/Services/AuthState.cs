using Blazored.LocalStorage;
using LocmiTimeCard.Web.Models;

namespace LocmiTimeCard.Web.Services;

public class AuthState(ILocalStorageService localStorage)
{
    private const string TokenKey = "locmi-time-card-token";
    private const string RoleKey = "locmi-time-card-role";
    private const string EmailKey = "locmi-time-card-email";

    public string? Token { get; private set; }
    public SessionIdentity Session { get; private set; } = new();

    public async Task LoadAsync()
    {
        Token = await localStorage.GetItemAsStringAsync(TokenKey);
        Session = new SessionIdentity
        {
            Role = await localStorage.GetItemAsStringAsync(RoleKey),
            Email = await localStorage.GetItemAsStringAsync(EmailKey)
        };
        Normalize();
    }

    public async Task SetAsync(LoginResponse response)
    {
        Token = response.Token;
        Session = new SessionIdentity { Role = response.Role, Email = response.Email };
        await localStorage.SetItemAsStringAsync(TokenKey, response.Token);
        await localStorage.SetItemAsStringAsync(RoleKey, response.Role);
        await localStorage.SetItemAsStringAsync(EmailKey, response.Email);
        Normalize();
    }

    public async Task ClearAsync()
    {
        Token = null;
        Session = new SessionIdentity();
        await localStorage.RemoveItemAsync(TokenKey);
        await localStorage.RemoveItemAsync(RoleKey);
        await localStorage.RemoveItemAsync(EmailKey);
    }

    private void Normalize()
    {
        if (string.IsNullOrWhiteSpace(Token)) Token = null;
        if (string.IsNullOrWhiteSpace(Session.Role)) Session.Role = null;
        if (string.IsNullOrWhiteSpace(Session.Email)) Session.Email = null;
    }
}
