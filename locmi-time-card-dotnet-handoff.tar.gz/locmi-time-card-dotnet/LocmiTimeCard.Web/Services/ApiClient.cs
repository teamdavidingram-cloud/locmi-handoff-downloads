using System.Net.Http.Headers;
using System.Net.Http.Json;
using LocmiTimeCard.Web.Models;

namespace LocmiTimeCard.Web.Services;

public class ApiClient(HttpClient httpClient, AuthState authState)
{
    public async Task<LoginResponse> LoginAsync(LoginRequest request)
    {
        var response = await httpClient.PostAsJsonAsync("api/auth/login", request);
        await EnsureSuccess(response, "Login failed");
        return (await response.Content.ReadFromJsonAsync<LoginResponse>())!;
    }

    public async Task LogoutAsync()
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "api/auth/logout");
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Logout failed");
    }

    public async Task<EmployeeDashboardResponse> GetEmployeeDashboardAsync(string? employeeEmail = null, string? date = null)
    {
        var query = new List<string>();
        if (!string.IsNullOrWhiteSpace(employeeEmail)) query.Add($"employeeEmail={Uri.EscapeDataString(employeeEmail)}");
        if (!string.IsNullOrWhiteSpace(date)) query.Add($"date={Uri.EscapeDataString(date)}");
        var url = "api/employee/dashboard" + (query.Count > 0 ? $"?{string.Join("&", query)}" : string.Empty);
        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to load employee dashboard");
        return (await response.Content.ReadFromJsonAsync<EmployeeDashboardResponse>())!;
    }

    public async Task<EmployeeDashboardResponse> PostEmployeeActionAsync(string action, string? employeeEmail = null)
    {
        var url = "api/employee/action" + (!string.IsNullOrWhiteSpace(employeeEmail) ? $"?employeeEmail={Uri.EscapeDataString(employeeEmail)}" : string.Empty);
        using var request = new HttpRequestMessage(HttpMethod.Post, url);
        request.Content = JsonContent.Create(new { action });
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Action failed");
        return (await response.Content.ReadFromJsonAsync<EmployeeDashboardResponse>())!;
    }

    public async Task<AdminWorkforceResponse> GetAdminDashboardAsync()
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "api/admin/dashboard");
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to load admin dashboard");
        return (await response.Content.ReadFromJsonAsync<AdminWorkforceResponse>())!;
    }

    public async Task<AdminEmployeeDetailResponse> GetAdminEmployeeDetailAsync(string email, string? date = null)
    {
        var url = $"api/admin/employee/{Uri.EscapeDataString(email)}" + (!string.IsNullOrWhiteSpace(date) ? $"?date={Uri.EscapeDataString(date)}" : string.Empty);
        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to load employee detail");
        return (await response.Content.ReadFromJsonAsync<AdminEmployeeDetailResponse>())!;
    }

    public async Task CreateEmployeeAsync(CreateEmployeeRequest payload)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "api/admin/employees");
        request.Content = JsonContent.Create(payload);
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to create employee");
    }

    public async Task UpdateEmployeeAsync(string email, CreateEmployeeRequest payload)
    {
        using var request = new HttpRequestMessage(HttpMethod.Put, $"api/admin/employees/{Uri.EscapeDataString(email)}");
        request.Content = JsonContent.Create(payload);
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to update employee");
    }

    public async Task DeactivateEmployeeAsync(string email)
    {
        using var request = new HttpRequestMessage(HttpMethod.Delete, $"api/admin/employees/{Uri.EscapeDataString(email)}");
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to deactivate employee");
    }

    public async Task<AdminAdjustmentResponse> PostAdjustmentAsync(AdminAdjustmentRequest payload)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "api/admin/adjustments");
        request.Content = JsonContent.Create(payload);
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to submit adjustment");
        return (await response.Content.ReadFromJsonAsync<AdminAdjustmentResponse>())!;
    }

    public async Task<(string FileName, string Csv)> GetPayrollCsvAsync(string? startDate = null, string? endDate = null)
    {
        var query = new List<string>();
        if (!string.IsNullOrWhiteSpace(startDate)) query.Add($"startDate={Uri.EscapeDataString(startDate)}");
        if (!string.IsNullOrWhiteSpace(endDate)) query.Add($"endDate={Uri.EscapeDataString(endDate)}");
        var url = "api/admin/payroll/export" + (query.Count > 0 ? $"?{string.Join("&", query)}" : string.Empty);
        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to export payroll CSV");
        var csv = await response.Content.ReadAsStringAsync();
        var fileName = response.Content.Headers.ContentDisposition?.FileName?.Trim('"')
            ?? $"locmi-time-card-payroll-{DateTime.UtcNow:yyyy-MM-dd}.csv";
        return (fileName, csv);
    }

    public async Task<UploadStaffImageResponse> UploadStaffImageAsync(string fileName, string mimeType, string dataBase64)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "api/uploads/staff-image");
        request.Content = JsonContent.Create(new { fileName, mimeType, dataBase64 });
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to upload staff image");
        return (await response.Content.ReadFromJsonAsync<UploadStaffImageResponse>())!;
    }

    public async Task UpdateStaffImageAsync(string email, string profileImageUrl)
    {
        using var request = new HttpRequestMessage(HttpMethod.Put, $"api/uploads/staff-image/{Uri.EscapeDataString(email)}");
        request.Content = JsonContent.Create(new { profileImageUrl });
        AttachAuth(request);
        var response = await httpClient.SendAsync(request);
        await EnsureSuccess(response, "Failed to update staff image");
    }

    private void AttachAuth(HttpRequestMessage request)
    {
        if (!string.IsNullOrWhiteSpace(authState.Token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", authState.Token);
        }
    }

    private static async Task EnsureSuccess(HttpResponseMessage response, string fallback)
    {
        if (response.IsSuccessStatusCode) return;
        var body = await response.Content.ReadAsStringAsync();
        throw new InvalidOperationException(string.IsNullOrWhiteSpace(body) ? fallback : body);
    }
}
