namespace LocmiTimeCard.Web.Models;

public class SessionIdentity
{
    public string? Role { get; set; }
    public string? Email { get; set; }
}

public class LoginRequest
{
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = "employee";
    public string Password { get; set; } = string.Empty;
}

public class LoginResponse
{
    public bool Ok { get; set; }
    public string Token { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}

public class EmployeeDashboardResponse
{
    public EmployeeCard Employee { get; set; } = new();
    public string SelectedDate { get; set; } = string.Empty;
    public List<string> Actions { get; set; } = [];
    public List<TimelineEvent> Timeline { get; set; } = [];
    public Totals Totals { get; set; } = new();
    public string LastActionNote { get; set; } = string.Empty;
}

public class EmployeeCard
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Shift { get; set; } = string.Empty;
    public string MonthHours { get; set; } = string.Empty;
    public string HourlyRate { get; set; } = string.Empty;
    public string? ProfileImageUrl { get; set; }
}

public class Totals
{
    public string Today { get; set; } = string.Empty;
    public string Break { get; set; } = string.Empty;
}

public class TimelineEvent
{
    public string Id { get; set; } = string.Empty;
    public string EventType { get; set; } = string.Empty;
    public string OccurredAt { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public string Detail { get; set; } = string.Empty;
    public string Icon { get; set; } = string.Empty;
}

public class AdminWorkforceResponse
{
    public Summary Summary { get; set; } = new();
    public List<WorkforceEmployee> Employees { get; set; } = [];
    public List<AdminAdjustmentHistoryItem> RecentAdjustments { get; set; } = [];
}

public class Summary
{
    public int ClockedIn { get; set; }
    public int OnBreak { get; set; }
    public int Alerts { get; set; }
}

public class WorkforceEmployee
{
    public string Name { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Context { get; set; } = string.Empty;
    public string? ProfileImageUrl { get; set; }
    public bool Active { get; set; }
    public string Email { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string HourlyRate { get; set; } = string.Empty;
    public string ShiftStart { get; set; } = string.Empty;
    public string ShiftEnd { get; set; } = string.Empty;
}

public class AdminAdjustmentHistoryItem
{
    public string EmployeeName { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
    public string AdminEmail { get; set; } = string.Empty;
    public string CreatedAt { get; set; } = string.Empty;
}

public class AdminEmployeeDetailResponse
{
    public AdminEmployeeCard Employee { get; set; } = new();
    public List<TimelineEvent> Timeline { get; set; } = [];
    public List<AdminAdjustmentHistoryItem> RecentAdjustments { get; set; } = [];
}

public class AdminEmployeeCard
{
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Shift { get; set; } = string.Empty;
    public string HourlyRate { get; set; } = string.Empty;
    public string? ProfileImageUrl { get; set; }
    public Totals Totals { get; set; } = new();
}

public class CreateEmployeeRequest
{
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public decimal HourlyRate { get; set; }
    public string ShiftStart { get; set; } = string.Empty;
    public string ShiftEnd { get; set; } = string.Empty;
    public string? ProfileImageUrl { get; set; }
}

public class AdminAdjustmentRequest
{
    public string EmployeeEmail { get; set; } = string.Empty;
    public string EventType { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
    public string? Note { get; set; }
}


public class UploadStaffImageResponse
{
    public bool Ok { get; set; }
    public string ImageUrl { get; set; } = string.Empty;
}

public class AdminAdjustmentResponse
{
    public bool Ok { get; set; }
    public string EmployeeName { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public Totals Totals { get; set; } = new();
    public Audit Audit { get; set; } = new();
}

public class Audit
{
    public string Reason { get; set; } = string.Empty;
    public string AdminEmail { get; set; } = string.Empty;
}
