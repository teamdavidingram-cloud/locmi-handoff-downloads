using System.Text.Json;
using LocmiTimeCard.Application.Contracts;
using LocmiTimeCard.Application.Models;
using LocmiTimeCard.Domain;
using LocmiTimeCard.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LocmiTimeCard.Infrastructure;

public class AttendanceService(LocmiTimeCardDbContext dbContext) : IAttendanceService
{
    private const string DefaultEmployeeEmail = "maria.santos@locmi.local";
    private const string AdminEmail = "admin@locmi.local";
    private static readonly Dictionary<string, (string Role, string Email)> Sessions = new();

    private readonly LocmiTimeCardDbContext _db = dbContext;

    private static readonly (string Email, string Password, string FullName, string Title, string Department, int HourlyRateCents, string ShiftStart, string ShiftEnd)[] SeedEmployees =
    [
        ("maria.santos@locmi.local", "maria123", "Maria Santos", "Reception Coordinator", "Reception", 2400, "8:00 AM", "4:30 PM"),
        ("james.lee@locmi.local", "james123", "James Lee", "Case Assistant", "Operations", 2200, "9:00 AM", "5:00 PM"),
        ("anika.patel@locmi.local", "anika123", "Anika Patel", "Paralegal", "Legal Support", 2800, "8:30 AM", "4:30 PM"),
        ("ruth.garcia@locmi.local", "ruth123", "Ruth Garcia", "Intake Specialist", "Intake", 2300, "9:00 AM", "5:30 PM")
    ];

    public async Task<LoginResponse?> LoginAsync(LoginRequest request)
    {
        await EnsureSeedDataAsync();
        var normalizedRole = request.Role.Equals("admin", StringComparison.OrdinalIgnoreCase) ? Role.Admin : Role.Employee;
        var user = await _db.Users.FirstOrDefaultAsync(x => x.Email == request.Email);
        if (user is null || user.PasswordHash != request.Password || user.Role != normalizedRole)
        {
            return null;
        }

        var token = Guid.NewGuid().ToString("N");
        Sessions[token] = (normalizedRole == Role.Admin ? "admin" : "employee", user.Email);
        return new LoginResponse(true, token, Sessions[token].Role, user.Email);
    }

    public SessionIdentityDto GetSession(string? token)
    {
        if (string.IsNullOrWhiteSpace(token) || !Sessions.TryGetValue(token, out var session))
        {
            return new SessionIdentityDto(null, null);
        }

        return new SessionIdentityDto(session.Role, session.Email);
    }

    public void Logout(string? token)
    {
        if (!string.IsNullOrWhiteSpace(token))
        {
            Sessions.Remove(token);
        }
    }

    public async Task<EmployeeDashboardDto> GetEmployeeDashboardAsync(string employeeEmail, string? forDate = null)
    {
        await EnsureSeedDataAsync();
        var targetEmail = string.IsNullOrWhiteSpace(employeeEmail) ? DefaultEmployeeEmail : employeeEmail;
        var selectedDate = forDate ?? DateTime.UtcNow.ToString("yyyy-MM-dd");
        var user = await _db.Users
            .Include(x => x.EmployeeProfile!)
                .ThenInclude(x => x.Department)
            .Include(x => x.EmployeeProfile!)
                .ThenInclude(x => x.TimeEntryDays.Where(d => d.WorkDate == DateOnlyToUtc(selectedDate)))
                    .ThenInclude(x => x.TimeEvents.OrderBy(e => e.OccurredAt))
            .FirstAsync(x => x.Email == targetEmail);

        var profile = user.EmployeeProfile!;
        var entry = profile.TimeEntryDays.FirstOrDefault() ?? await EnsureDayEntryAsync(profile.Id, selectedDate);
        var status = DeriveStatus(entry.TimeEvents.Select(x => x.EventType).ToList());
        var totals = CalculateTotals(entry.TimeEvents, status);
        await PersistDerivedStateAsync(profile, entry, status, totals);
        var isToday = selectedDate == DateTime.UtcNow.ToString("yyyy-MM-dd");

        return new EmployeeDashboardDto(
            MapEmployeeCard(profile, user, status, totals),
            selectedDate,
            isToday ? AllowedActions(status).Select(x => x.ToString().ToUpperSnake()).ToList() : [],
            MapTimeline(entry.TimeEvents),
            new TotalsDto(FormatMinutes(totals.WorkedMinutes), FormatBreakMinutes(totals.BreakMinutes)),
            entry.TimeEvents.Count > 0 ? EventPresentation(entry.TimeEvents.Last().EventType).Detail : "Ready to start the shift.");
    }

    public async Task<EmployeeDashboardDto?> ApplyEmployeeActionAsync(string employeeEmail, string action)
    {
        await EnsureSeedDataAsync();
        var parsed = ParseAction(action);
        var targetEmail = string.IsNullOrWhiteSpace(employeeEmail) ? DefaultEmployeeEmail : employeeEmail;
        var user = await _db.Users.Include(x => x.EmployeeProfile).FirstAsync(x => x.Email == targetEmail);
        var profile = user.EmployeeProfile!;
        var entry = await EnsureDayEntryAsync(profile.Id, null);
        await _db.Entry(entry).Collection(x => x.TimeEvents).LoadAsync();
        var status = DeriveStatus(entry.TimeEvents.OrderBy(x => x.OccurredAt).Select(x => x.EventType).ToList());
        if (!AllowedActions(status).Contains(parsed)) return null;

        if (parsed == TimeEventType.ClockIn && status == AttendanceStatus.ClockedOut)
        {
            _db.TimeEvents.RemoveRange(entry.TimeEvents);
            await _db.SaveChangesAsync();
            entry = await EnsureDayEntryAsync(profile.Id, null);
            await _db.Entry(entry).Collection(x => x.TimeEvents).LoadAsync();
        }

        _db.TimeEvents.Add(new TimeEvent
        {
            TimeEntryDayId = entry.Id,
            EventType = parsed,
            OccurredAt = DateTime.UtcNow,
            Note = EventPresentation(parsed).Detail,
            DeviceLabel = "Front desk iPhone"
        });
        await _db.SaveChangesAsync();
        return await GetEmployeeDashboardAsync(targetEmail);
    }

    public async Task<AdminWorkforceDto> GetAdminWorkforceAsync()
    {
        await EnsureSeedDataAsync();
        var today = DateOnlyToUtc(DateTime.UtcNow.ToString("yyyy-MM-dd"));
        var profiles = await _db.EmployeeProfiles
            .Where(x => x.IsActive)
            .Include(x => x.User)
            .Include(x => x.Department)
            .Include(x => x.TimeEntryDays.Where(d => d.WorkDate == today))
                .ThenInclude(x => x.TimeEvents.OrderBy(e => e.OccurredAt))
            .Include(x => x.TimeEntryDays.Where(d => d.WorkDate == today))
                .ThenInclude(x => x.AdjustmentLogs.OrderByDescending(a => a.CreatedAt).Take(1))
            .OrderBy(x => x.User.FullName)
            .ToListAsync();

        var employees = new List<WorkforceEmployeeDto>();
        var statuses = new List<AttendanceStatus>();
        foreach (var profile in profiles)
        {
            var entry = profile.TimeEntryDays.FirstOrDefault();
            var status = DeriveStatus(entry?.TimeEvents.Select(x => x.EventType).ToList() ?? []);
            var totals = CalculateTotals(entry?.TimeEvents ?? [], status);
            await PersistDerivedStateAsync(profile, entry, status, totals);
            statuses.Add(status);
            var latestAdjustment = entry?.AdjustmentLogs.OrderByDescending(x => x.CreatedAt).FirstOrDefault();
            var context = latestAdjustment is not null
                ? $"Adjusted: {latestAdjustment.Reason}"
                : entry is not null && entry.TimeEvents.Count > 0
                    ? $"Today {FormatMinutes(totals.WorkedMinutes)}, break {FormatBreakMinutes(totals.BreakMinutes)}"
                    : $"Scheduled {profile.DefaultShiftStart ?? "8:00 AM"} to {profile.DefaultShiftEnd ?? "4:30 PM"}";

            employees.Add(new WorkforceEmployeeDto(
                profile.User.FullName,
                status.ToString().ToUpperSnake(),
                context,
                profile.ProfileImageUrl,
                profile.IsActive,
                profile.User.Email,
                profile.Department?.Name ?? string.Empty,
                profile.Title ?? string.Empty,
                ((profile.HourlyRateCents ?? 0) / 100m).ToString("0.00"),
                profile.DefaultShiftStart ?? string.Empty,
                profile.DefaultShiftEnd ?? string.Empty));
        }

        var logs = await _db.AdjustmentLogs
            .Include(x => x.AdminUser)
            .Include(x => x.TimeEntryDay)
                .ThenInclude(x => x.EmployeeProfile)
                    .ThenInclude(x => x.User)
            .OrderByDescending(x => x.CreatedAt)
            .Take(8)
            .ToListAsync();

        return new AdminWorkforceDto(
            new SummaryDto(statuses.Count(x => x == AttendanceStatus.ClockedIn), statuses.Count(x => x == AttendanceStatus.OnBreak), statuses.Count(x => x == AttendanceStatus.ClockedOut)),
            employees,
            logs.Select(log => new AdminAdjustmentHistoryItemDto(log.TimeEntryDay.EmployeeProfile.User.FullName, log.Reason, log.AdminUser.Email, log.CreatedAt.ToString("O"))).ToList());
    }

    public async Task<AdminEmployeeDetailDto> GetAdminEmployeeDetailAsync(string employeeEmail, string? forDate = null)
    {
        await EnsureSeedDataAsync();
        var selectedDate = forDate ?? DateTime.UtcNow.ToString("yyyy-MM-dd");
        var workDate = DateOnlyToUtc(selectedDate);
        var user = await _db.Users
            .Include(x => x.EmployeeProfile!)
                .ThenInclude(x => x.Department)
            .Include(x => x.EmployeeProfile!)
                .ThenInclude(x => x.TimeEntryDays.Where(d => d.WorkDate == workDate))
                    .ThenInclude(x => x.TimeEvents.OrderBy(e => e.OccurredAt))
            .Include(x => x.EmployeeProfile!)
                .ThenInclude(x => x.TimeEntryDays.Where(d => d.WorkDate == workDate))
                    .ThenInclude(x => x.AdjustmentLogs.OrderByDescending(a => a.CreatedAt))
                        .ThenInclude(x => x.AdminUser)
            .FirstAsync(x => x.Email == employeeEmail);

        var profile = user.EmployeeProfile!;
        var entry = profile.TimeEntryDays.FirstOrDefault();
        var status = DeriveStatus(entry?.TimeEvents.Select(x => x.EventType).ToList() ?? []);
        var totals = CalculateTotals(entry?.TimeEvents ?? [], status);

        return new AdminEmployeeDetailDto(
            new AdminEmployeeCardDto(
                user.FullName,
                user.Email,
                profile.Department?.Name ?? string.Empty,
                profile.Title ?? "Employee",
                status.ToString().ToUpperSnake(),
                $"{profile.DefaultShiftStart ?? "8:00 AM"} to {profile.DefaultShiftEnd ?? "4:30 PM"}",
                $"{((profile.HourlyRateCents ?? 0) / 100m):0.00}/hr",
                profile.ProfileImageUrl,
                new TotalsDto(FormatMinutes(totals.WorkedMinutes), FormatBreakMinutes(totals.BreakMinutes))),
            MapTimeline(entry?.TimeEvents ?? []),
            (entry?.AdjustmentLogs ?? []).Select(log => new AdminAdjustmentHistoryItemDto(user.FullName, log.Reason, log.AdminUser.Email, log.CreatedAt.ToString("O"))).ToList());
    }

    public async Task<(bool Ok, string EmployeeEmail, string? Error)> CreateEmployeeAsync(CreateEmployeeRequest request)
    {
        await EnsureSeedDataAsync();
        var email = $"{request.FirstName.Trim().ToLowerInvariant()}.{request.LastName.Trim().ToLowerInvariant()}@locmi.local";
        if (await _db.Users.AnyAsync(x => x.Email == email)) return (false, string.Empty, "Employee already exists");
        var department = await UpsertDepartmentAsync(request.Department);
        var user = new User { Email = email, FullName = $"{request.FirstName.Trim()} {request.LastName.Trim()}".Trim(), Role = Role.Employee, PasswordHash = "welcome123" };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        _db.EmployeeProfiles.Add(new EmployeeProfile
        {
            UserId = user.Id,
            DepartmentId = department.Id,
            Title = request.Title.Trim(),
            HourlyRateCents = (int)Math.Round(request.HourlyRate * 100m),
            DefaultShiftStart = request.ShiftStart.Trim(),
            DefaultShiftEnd = request.ShiftEnd.Trim(),
            ProfileImageUrl = string.IsNullOrWhiteSpace(request.ProfileImageUrl) ? null : request.ProfileImageUrl.Trim(),
            IsActive = true
        });
        await _db.SaveChangesAsync();
        return (true, email, null);
    }

    public async Task<(bool Ok, string EmployeeEmail, string? Error)> UpdateEmployeeAsync(string employeeEmail, CreateEmployeeRequest request)
    {
        await EnsureSeedDataAsync();
        var user = await _db.Users.Include(x => x.EmployeeProfile).FirstOrDefaultAsync(x => x.Email == employeeEmail);
        if (user?.EmployeeProfile is null) return (false, string.Empty, "Employee profile not found");
        var department = await UpsertDepartmentAsync(request.Department);
        user.FullName = $"{request.FirstName.Trim()} {request.LastName.Trim()}".Trim();
        user.UpdatedAt = DateTime.UtcNow;
        user.EmployeeProfile.DepartmentId = department.Id;
        user.EmployeeProfile.Title = request.Title.Trim();
        user.EmployeeProfile.HourlyRateCents = (int)Math.Round(request.HourlyRate * 100m);
        user.EmployeeProfile.DefaultShiftStart = request.ShiftStart.Trim();
        user.EmployeeProfile.DefaultShiftEnd = request.ShiftEnd.Trim();
        user.EmployeeProfile.ProfileImageUrl = string.IsNullOrWhiteSpace(request.ProfileImageUrl) ? null : request.ProfileImageUrl.Trim();
        user.EmployeeProfile.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return (true, user.Email, null);
    }

    public async Task<(bool Ok, string? Error)> DeactivateEmployeeAsync(string employeeEmail)
    {
        await EnsureSeedDataAsync();
        var profile = await _db.EmployeeProfiles.Include(x => x.User).FirstOrDefaultAsync(x => x.User.Email == employeeEmail);
        if (profile is null) return (false, "Employee profile not found");
        profile.IsActive = false;
        profile.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return (true, null);
    }

    public async Task<AdminAdjustmentResponse> ApplyAdminAdjustmentAsync(AdminAdjustmentRequest request)
    {
        await EnsureSeedDataAsync();
        var adminUser = await _db.Users.FirstAsync(x => x.Email == AdminEmail);
        var employeeUser = await _db.Users.Include(x => x.EmployeeProfile).FirstAsync(x => x.Email == request.EmployeeEmail);
        var profile = employeeUser.EmployeeProfile ?? throw new InvalidOperationException("Employee profile not found");
        var entry = await EnsureDayEntryAsync(profile.Id, null);
        await _db.Entry(entry).Collection(x => x.TimeEvents).LoadAsync();
        var beforeState = JsonSerializer.Serialize(new
        {
            entry.Status,
            entry.TotalMinutesWorked,
            entry.TotalBreakMinutes,
            EventCount = entry.TimeEvents.Count
        });
        var eventType = ParseAction(request.EventType);
        _db.TimeEvents.Add(new TimeEvent
        {
            TimeEntryDayId = entry.Id,
            EventType = eventType,
            OccurredAt = DateTime.UtcNow,
            Note = string.IsNullOrWhiteSpace(request.Note) ? request.Reason : request.Note,
            DeviceLabel = "Admin override"
        });
        await _db.SaveChangesAsync();
        entry = await _db.TimeEntryDays.Include(x => x.TimeEvents.OrderBy(e => e.OccurredAt)).FirstAsync(x => x.Id == entry.Id);
        var status = DeriveStatus(entry.TimeEvents.Select(x => x.EventType).ToList());
        var totals = CalculateTotals(entry.TimeEvents, status);
        await PersistDerivedStateAsync(profile, entry, status, totals);
        var afterState = JsonSerializer.Serialize(new
        {
            Status = status,
            TotalMinutesWorked = totals.WorkedMinutes,
            TotalBreakMinutes = totals.BreakMinutes,
            EventCount = entry.TimeEvents.Count,
            LastEventType = eventType.ToString()
        });
        _db.AdjustmentLogs.Add(new AdjustmentLog
        {
            TimeEntryDayId = entry.Id,
            AdminUserId = adminUser.Id,
            Reason = request.Reason,
            BeforeJson = beforeState,
            AfterJson = afterState
        });
        await _db.SaveChangesAsync();
        return new AdminAdjustmentResponse(true, employeeUser.FullName, status.ToString().ToUpperSnake(), new TotalsDto(FormatMinutes(totals.WorkedMinutes), FormatBreakMinutes(totals.BreakMinutes)), new AuditDto(request.Reason, adminUser.Email));
    }

    public async Task<UploadStaffImageResponse> SaveStaffImageAsync(UploadStaffImageRequest request, string webRootPath, string? basePath = null)
    {
        var safeName = string.Concat(request.FileName.Select(ch => char.IsLetterOrDigit(ch) || ch is '.' or '_' or '-' ? ch : '_'));
        var ext = Path.GetExtension(safeName);
        if (string.IsNullOrWhiteSpace(ext)) ext = request.MimeType?.Contains("png", StringComparison.OrdinalIgnoreCase) == true ? ".png" : ".jpg";
        var finalName = $"{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}-{Path.GetFileNameWithoutExtension(safeName)}{ext}";
        var uploadsDir = Path.Combine(webRootPath, "uploads", "staff");
        Directory.CreateDirectory(uploadsDir);
        var bytes = Convert.FromBase64String(request.DataBase64);
        await File.WriteAllBytesAsync(Path.Combine(uploadsDir, finalName), bytes);
        var prefix = string.IsNullOrWhiteSpace(basePath) ? string.Empty : $"/{basePath.Trim('/')}";
        return new UploadStaffImageResponse(true, $"{prefix}/uploads/staff/{finalName}");
    }

    public async Task<(bool Ok, string ProfileImageUrl, string? Error)> UpdateEmployeeProfileImageAsync(string employeeEmail, string profileImageUrl)
    {
        await EnsureSeedDataAsync();
        var profile = await _db.EmployeeProfiles.Include(x => x.User).FirstOrDefaultAsync(x => x.User.Email == employeeEmail);
        if (profile is null) return (false, string.Empty, "Employee profile not found");
        profile.ProfileImageUrl = profileImageUrl.Trim();
        profile.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return (true, profile.ProfileImageUrl, null);
    }

    public async Task<(string FileName, string ContentType, string Csv)> ExportPayrollCsvAsync(string? startDate, string? endDate)
    {
        await EnsureSeedDataAsync();
        var start = string.IsNullOrWhiteSpace(startDate) ? DateTime.UtcNow.Date : DateTime.Parse(startDate).Date;
        var end = string.IsNullOrWhiteSpace(endDate) ? DateTime.UtcNow.Date.AddDays(1).AddTicks(-1) : DateTime.Parse(endDate).Date.AddDays(1).AddTicks(-1);
        var profiles = await _db.EmployeeProfiles
            .Include(x => x.User)
            .Include(x => x.Department)
            .Include(x => x.TimeEntryDays.Where(d => d.WorkDate >= start && d.WorkDate <= end))
                .ThenInclude(x => x.TimeEvents.OrderBy(e => e.OccurredAt))
            .OrderBy(x => x.User.FullName)
            .ToListAsync();

        var rows = new List<string>
        {
            "\"Employee Name\",\"Department\",\"Role\",\"Status\",\"Worked Minutes\",\"Break Minutes\",\"Hourly Rate\",\"Work Date\""
        };

        foreach (var profile in profiles)
        {
            foreach (var entry in profile.TimeEntryDays.OrderBy(x => x.WorkDate))
            {
                var status = DeriveStatus(entry.TimeEvents.Select(x => x.EventType).ToList());
                var totals = CalculateTotals(entry.TimeEvents, status);
                var row = new[]
                {
                    profile.User.FullName,
                    profile.Department?.Name ?? string.Empty,
                    profile.Title ?? string.Empty,
                    status.ToString().ToUpperSnake(),
                    totals.WorkedMinutes.ToString(),
                    totals.BreakMinutes.ToString(),
                    ((profile.HourlyRateCents ?? 0) / 100m).ToString("0.00"),
                    entry.WorkDate.ToString("yyyy-MM-dd")
                };
                rows.Add(string.Join(',', row.Select(value => $"\"{value.Replace("\"", "\"\"")}\"")));
            }
        }

        return ($"locmi-time-card-payroll-{start:yyyy-MM-dd}-to-{end:yyyy-MM-dd}.csv", "text/csv; charset=utf-8", string.Join('\n', rows));
    }

    private async Task EnsureSeedDataAsync()
    {
        if (await _db.Users.AnyAsync()) return;

        _db.Users.Add(new User
        {
            Email = AdminEmail,
            FullName = "LOCMI Admin",
            Role = Role.Admin,
            PasswordHash = "admin123"
        });
        await _db.SaveChangesAsync();

        foreach (var seed in SeedEmployees)
        {
            var department = await UpsertDepartmentAsync(seed.Department);
            var user = new User
            {
                Email = seed.Email,
                FullName = seed.FullName,
                Role = Role.Employee,
                PasswordHash = seed.Password
            };
            _db.Users.Add(user);
            await _db.SaveChangesAsync();
            var profile = new EmployeeProfile
            {
                UserId = user.Id,
                DepartmentId = department.Id,
                Title = seed.Title,
                HourlyRateCents = seed.HourlyRateCents,
                DefaultShiftStart = seed.ShiftStart,
                DefaultShiftEnd = seed.ShiftEnd,
                IsActive = true
            };
            _db.EmployeeProfiles.Add(profile);
            await _db.SaveChangesAsync();
            await EnsureDayEntryAsync(profile.Id, null);
        }
    }

    private async Task<Department> UpsertDepartmentAsync(string name)
    {
        var trimmed = name.Trim();
        var department = await _db.Departments.FirstOrDefaultAsync(x => x.Name == trimmed);
        if (department is not null) return department;
        department = new Department { Name = trimmed };
        _db.Departments.Add(department);
        await _db.SaveChangesAsync();
        return department;
    }

    private async Task<TimeEntryDay> EnsureDayEntryAsync(Guid employeeProfileId, string? forDate)
    {
        var workDate = DateOnlyToUtc(forDate ?? DateTime.UtcNow.ToString("yyyy-MM-dd"));
        var existing = await _db.TimeEntryDays
            .Include(x => x.TimeEvents.OrderBy(e => e.OccurredAt))
            .Include(x => x.AdjustmentLogs.OrderByDescending(a => a.CreatedAt))
            .FirstOrDefaultAsync(x => x.EmployeeProfileId == employeeProfileId && x.WorkDate == workDate);
        if (existing is not null) return existing;
        var entry = new TimeEntryDay { EmployeeProfileId = employeeProfileId, WorkDate = workDate };
        _db.TimeEntryDays.Add(entry);
        await _db.SaveChangesAsync();
        return await _db.TimeEntryDays.Include(x => x.TimeEvents).Include(x => x.AdjustmentLogs).FirstAsync(x => x.Id == entry.Id);
    }

    private async Task PersistDerivedStateAsync(EmployeeProfile profile, TimeEntryDay? entry, AttendanceStatus status, (int WorkedMinutes, int BreakMinutes) totals)
    {
        var dirty = false;
        if (profile.ActiveStatus != status)
        {
            profile.ActiveStatus = status;
            profile.UpdatedAt = DateTime.UtcNow;
            dirty = true;
        }
        if (entry is not null && (entry.Status != status || entry.TotalMinutesWorked != totals.WorkedMinutes || entry.TotalBreakMinutes != totals.BreakMinutes))
        {
            entry.Status = status;
            entry.TotalMinutesWorked = totals.WorkedMinutes;
            entry.TotalBreakMinutes = totals.BreakMinutes;
            entry.UpdatedAt = DateTime.UtcNow;
            dirty = true;
        }
        if (dirty) await _db.SaveChangesAsync();
    }

    private static List<TimelineEventDto> MapTimeline(IEnumerable<TimeEvent> events) => events
        .OrderBy(x => x.OccurredAt)
        .Select(x =>
        {
            var presentation = EventPresentation(x.EventType);
            return new TimelineEventDto(x.Id.ToString(), x.EventType.ToString().ToUpperSnake(), x.OccurredAt.ToLocalTime().ToString("h:mm tt"), presentation.Label, presentation.Detail, presentation.Icon);
        })
        .ToList();

    private static EmployeeCardDto MapEmployeeCard(EmployeeProfile profile, User user, AttendanceStatus status, (int WorkedMinutes, int BreakMinutes) totals) =>
        new(
            profile.Id.ToString(),
            user.FullName,
            profile.Title ?? "Employee",
            profile.Department?.Name ?? "Reception",
            status.ToString().ToUpperSnake(),
            $"{profile.DefaultShiftStart ?? "8:00 AM"} to {profile.DefaultShiftEnd ?? "4:30 PM"}",
            FormatMinutes(totals.WorkedMinutes),
            $"${((profile.HourlyRateCents ?? 2400) / 100m):0}/hr",
            profile.ProfileImageUrl);

    private static DateTime DateOnlyToUtc(string yyyyMmDd) => DateTime.SpecifyKind(DateTime.Parse($"{yyyyMmDd}T00:00:00"), DateTimeKind.Utc);

    private static TimeEventType ParseAction(string action) => action.Trim().ToUpperInvariant() switch
    {
        "CLOCK_IN" => TimeEventType.ClockIn,
        "BREAK_START" => TimeEventType.BreakStart,
        "BREAK_END" => TimeEventType.BreakEnd,
        "CLOCK_OUT" => TimeEventType.ClockOut,
        _ => throw new InvalidOperationException("Unsupported action")
    };

    private static List<TimeEventType> AllowedActions(AttendanceStatus status) => status switch
    {
        AttendanceStatus.NotClockedIn => [TimeEventType.ClockIn],
        AttendanceStatus.ClockedIn => [TimeEventType.BreakStart, TimeEventType.ClockOut],
        AttendanceStatus.OnBreak => [TimeEventType.BreakEnd],
        AttendanceStatus.ClockedOut => [TimeEventType.ClockIn],
        _ => [TimeEventType.ClockIn]
    };

    private static AttendanceStatus DeriveStatus(List<TimeEventType> eventTypes)
    {
        if (eventTypes.Count == 0) return AttendanceStatus.NotClockedIn;
        return eventTypes.Last() switch
        {
            TimeEventType.ClockIn or TimeEventType.BreakEnd => AttendanceStatus.ClockedIn,
            TimeEventType.BreakStart => AttendanceStatus.OnBreak,
            TimeEventType.ClockOut => AttendanceStatus.ClockedOut,
            _ => AttendanceStatus.NotClockedIn
        };
    }

    private static (int WorkedMinutes, int BreakMinutes) CalculateTotals(IEnumerable<TimeEvent> events, AttendanceStatus status)
    {
        var ordered = events.OrderBy(x => x.OccurredAt).ToList();
        var worked = 0;
        var breakMinutes = 0;
        DateTime? currentBreak = null;
        DateTime? lastWorkResume = null;
        DateTime? currentClockIn = null;

        foreach (var evt in ordered)
        {
            switch (evt.EventType)
            {
                case TimeEventType.ClockIn:
                    currentClockIn = evt.OccurredAt;
                    lastWorkResume = evt.OccurredAt;
                    currentBreak = null;
                    break;
                case TimeEventType.BreakStart when lastWorkResume.HasValue:
                    worked += MinutesBetween(lastWorkResume.Value, evt.OccurredAt);
                    currentBreak = evt.OccurredAt;
                    lastWorkResume = null;
                    break;
                case TimeEventType.BreakEnd when currentBreak.HasValue:
                    breakMinutes += MinutesBetween(currentBreak.Value, evt.OccurredAt);
                    currentBreak = null;
                    lastWorkResume = evt.OccurredAt;
                    break;
                case TimeEventType.ClockOut:
                    if (lastWorkResume.HasValue) worked += MinutesBetween(lastWorkResume.Value, evt.OccurredAt);
                    if (currentBreak.HasValue) breakMinutes += MinutesBetween(currentBreak.Value, evt.OccurredAt);
                    currentClockIn = null;
                    currentBreak = null;
                    lastWorkResume = null;
                    break;
            }
        }

        if ((status == AttendanceStatus.ClockedIn || status == AttendanceStatus.OnBreak) && currentClockIn.HasValue)
        {
            var now = DateTime.UtcNow;
            if (status == AttendanceStatus.ClockedIn && lastWorkResume.HasValue) worked += MinutesBetween(lastWorkResume.Value, now);
            if (status == AttendanceStatus.OnBreak && currentBreak.HasValue) breakMinutes += MinutesBetween(currentBreak.Value, now);
        }

        return (worked, breakMinutes);
    }

    private static int MinutesBetween(DateTime start, DateTime end) => Math.Max(0, (int)Math.Round((end - start).TotalMinutes));
    private static string FormatMinutes(int totalMinutes) => $"{totalMinutes / 60}h {totalMinutes % 60:00}m";
    private static string FormatBreakMinutes(int totalMinutes) => $"{totalMinutes}m";

    private static (string Label, string Detail, string Icon) EventPresentation(TimeEventType eventType) => eventType switch
    {
        TimeEventType.ClockIn => ("Clocked In", "Front desk iPhone", "⏱"),
        TimeEventType.BreakStart => ("Started Break", "Break recorded automatically", "☕"),
        TimeEventType.BreakEnd => ("Ended Break", "Returned to active work", "🔙"),
        TimeEventType.ClockOut => ("Clocked Out", "Shift completed", "⛔"),
        _ => ("Adjusted", "Admin override", "🛠")
    };
}

internal static class StringExtensions
{
    public static string ToUpperSnake(this string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return value;
        return string.Concat(value.Select((ch, index) => index > 0 && char.IsUpper(ch) ? $"_{ch}" : ch.ToString())).ToUpperInvariant();
    }

    public static string ToUpperSnake(this AttendanceStatus status) => status.ToString().ToUpperSnake();
}
