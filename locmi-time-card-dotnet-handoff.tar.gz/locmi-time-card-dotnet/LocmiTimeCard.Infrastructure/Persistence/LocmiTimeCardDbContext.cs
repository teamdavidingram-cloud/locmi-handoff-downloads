using LocmiTimeCard.Domain;
using Microsoft.EntityFrameworkCore;

namespace LocmiTimeCard.Infrastructure.Persistence;

public class LocmiTimeCardDbContext(DbContextOptions<LocmiTimeCardDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<EmployeeProfile> EmployeeProfiles => Set<EmployeeProfile>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<TimeEntryDay> TimeEntryDays => Set<TimeEntryDay>();
    public DbSet<TimeEvent> TimeEvents => Set<TimeEvent>();
    public DbSet<AdjustmentLog> AdjustmentLogs => Set<AdjustmentLog>();
    public DbSet<DeviceLog> DeviceLogs => Set<DeviceLog>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.Email).IsUnique();
            entity.Property(x => x.Email).IsRequired();
            entity.Property(x => x.FullName).IsRequired();
            entity.Property(x => x.Role).HasConversion<string>();
        });

        modelBuilder.Entity<EmployeeProfile>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.UserId).IsUnique();
            entity.Property(x => x.ActiveStatus).HasConversion<string>();
            entity.HasOne(x => x.User)
                .WithOne(x => x.EmployeeProfile)
                .HasForeignKey<EmployeeProfile>(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(x => x.Department)
                .WithMany(x => x.Employees)
                .HasForeignKey(x => x.DepartmentId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.Name).IsUnique();
            entity.Property(x => x.Name).IsRequired();
        });

        modelBuilder.Entity<TimeEntryDay>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Status).HasConversion<string>();
            entity.HasIndex(x => new { x.EmployeeProfileId, x.WorkDate }).IsUnique();
            entity.HasOne(x => x.EmployeeProfile)
                .WithMany(x => x.TimeEntryDays)
                .HasForeignKey(x => x.EmployeeProfileId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<TimeEvent>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.EventType).HasConversion<string>();
            entity.Property(x => x.BreakType).HasConversion<string>();
            entity.HasOne(x => x.TimeEntryDay)
                .WithMany(x => x.TimeEvents)
                .HasForeignKey(x => x.TimeEntryDayId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<AdjustmentLog>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Reason).IsRequired();
            entity.Property(x => x.BeforeJson).IsRequired();
            entity.Property(x => x.AfterJson).IsRequired();
            entity.HasOne(x => x.AdminUser)
                .WithMany(x => x.AdjustmentLogs)
                .HasForeignKey(x => x.AdminUserId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(x => x.TimeEntryDay)
                .WithMany(x => x.AdjustmentLogs)
                .HasForeignKey(x => x.TimeEntryDayId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<DeviceLog>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.Label).IsRequired();
            entity.HasOne(x => x.EmployeeProfile)
                .WithMany(x => x.DeviceLogs)
                .HasForeignKey(x => x.EmployeeProfileId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
