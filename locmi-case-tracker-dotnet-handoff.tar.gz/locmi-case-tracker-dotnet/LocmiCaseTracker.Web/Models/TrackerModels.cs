namespace LocmiCaseTracker.Web.Models;

public class TrackerState
{
    public List<CaseRow> Rows { get; set; } = [];
    public ITAdminConfig ItAdminConfig { get; set; } = new();
}

public class CaseRow
{
    public string Id { get; set; } = string.Empty;
    public string CaseNumber { get; set; } = string.Empty;
    public string ClientName { get; set; } = string.Empty;
    public string CaseworkTeam { get; set; } = string.Empty;
    public string Caseworker { get; set; } = string.Empty;
    public string RetentionDate { get; set; } = string.Empty;
    public string Deadline { get; set; } = string.Empty;
    public int RemainingDays { get; set; }
    public string Os { get; set; } = string.Empty;
    public string CrqMissingDocs { get; set; } = string.Empty;
    public string CrqStatus { get; set; } = string.Empty;
    public string QuestionnaireStatus { get; set; } = string.Empty;
    public string ApprovalStatus { get; set; } = string.Empty;
    public string ArgumentStatus { get; set; } = string.Empty;
    public string FinalMeritsStatus { get; set; } = string.Empty;
    public string CoverLetterStatus { get; set; } = string.Empty;
    public string CaseStatusReport { get; set; } = string.Empty;
    public string Reminder { get; set; } = string.Empty;
    public List<string> SelectedCategories { get; set; } = [];
    public List<CategoryStageState> StageBreakdown { get; set; } = [];
}

public class CategoryStageState
{
    public string Category { get; set; } = string.Empty;
    public string Questionnaire { get; set; } = string.Empty;
    public string Approval { get; set; } = string.Empty;
    public string Arguments { get; set; } = string.Empty;
    public string ArgumentSupervisorDecision { get; set; } = string.Empty;
    public string ArgumentSupervisorFeedback { get; set; } = string.Empty;
}

public class SourceRegistryRecord
{
    public string Id { get; set; } = string.Empty;
    public string CaseNumber { get; set; } = string.Empty;
    public string ClientName { get; set; } = string.Empty;
    public string OnboardingSpecialist { get; set; } = string.Empty;
    public string Caseworker { get; set; } = string.Empty;
    public string RetainedDate { get; set; } = string.Empty;
    public List<string> Categories { get; set; } = [];
}

public class FrontlineConnectionConfig
{
    public string Endpoint { get; set; } = string.Empty;
    public string AuthType { get; set; } = "none";
    public string AuthToken { get; set; } = string.Empty;
    public string ApiKeyHeader { get; set; } = "x-api-key";
    public string CaseNumberParam { get; set; } = "caseNumber";
}

public class ITAdminConfig
{
    public List<SourceRegistryRecord> SourceRegistry { get; set; } = [];
    public string SyncFrequency { get; set; } = "Per case entry";
    public string Notes { get; set; } = string.Empty;
    public FrontlineConnectionConfig FrontlineConnection { get; set; } = new();
}

public class FrontlineLookupResult
{
    public bool Ok { get; set; }
    public string? Mode { get; set; }
    public string? CaseNumber { get; set; }
    public CaseRow? PreviewRow { get; set; }
    public SourceRegistryRecord? SourceRecord { get; set; }
    public TrackerState? State { get; set; }
    public string? Error { get; set; }
}
