namespace LocmiCaseTracker.Web.Models;

public class ImportPreviewRow
{
    public Dictionary<string, string> Cells { get; set; } = [];
}

public class ValidationIssue
{
    public string Level { get; set; } = "warning";
    public string Message { get; set; } = string.Empty;
}
