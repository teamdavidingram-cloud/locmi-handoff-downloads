using System.Net.Http.Json;
using LocmiCaseTracker.Web.Models;

namespace LocmiCaseTracker.Web.Services;

public class ApiClient(HttpClient httpClient)
{
    public async Task<TrackerState> GetStateAsync()
        => (await httpClient.GetFromJsonAsync<TrackerState>("api/state"))!;

    public async Task<TrackerState> SaveStateAsync(TrackerState state)
    {
        var response = await httpClient.PutAsJsonAsync("api/state", state);
        response.EnsureSuccessStatusCode();
        var wrapped = await response.Content.ReadFromJsonAsync<SaveStateResponse>();
        return wrapped?.State ?? state;
    }

    public async Task<FrontlineLookupResult> TestFrontlineAsync(string caseNumber)
        => await PostAsync("api/frontline/test", caseNumber);

    public async Task<FrontlineLookupResult> PreviewFrontlineAsync(string caseNumber)
        => await PostAsync("api/frontline/preview", caseNumber);

    public async Task<FrontlineLookupResult> ApplyFrontlineAsync(string caseNumber)
        => await PostAsync("api/frontline/apply", caseNumber);

    private async Task<FrontlineLookupResult> PostAsync(string url, string caseNumber)
    {
        var response = await httpClient.PostAsJsonAsync(url, new { caseNumber });
        return (await response.Content.ReadFromJsonAsync<FrontlineLookupResult>()) ?? new FrontlineLookupResult { Ok = false, Error = "Request failed" };
    }

    private class SaveStateResponse
    {
        public bool Ok { get; set; }
        public TrackerState? State { get; set; }
    }
}
