using LocmiCaseTracker.Domain;

namespace LocmiCaseTracker.Application.Contracts;

public interface ITrackerStateService
{
    Task<TrackerState> GetStateAsync(CancellationToken cancellationToken = default);
    Task<TrackerState> SaveStateAsync(TrackerState state, CancellationToken cancellationToken = default);
    Task<FrontlineLookupResult> TestFrontlineAsync(string caseNumber, CancellationToken cancellationToken = default);
    Task<FrontlineLookupResult> PreviewFrontlineAsync(string caseNumber, CancellationToken cancellationToken = default);
    Task<FrontlineLookupResult> ApplyFrontlineAsync(string caseNumber, CancellationToken cancellationToken = default);
}

public sealed class FrontlineLookupResult
{
    public bool Ok { get; set; }
    public string? Mode { get; set; }
    public string? CaseNumber { get; set; }
    public CaseRow? PreviewRow { get; set; }
    public FrontlineSourceRecord? SourceRecord { get; set; }
    public TrackerState? State { get; set; }
    public string? Error { get; set; }
}
