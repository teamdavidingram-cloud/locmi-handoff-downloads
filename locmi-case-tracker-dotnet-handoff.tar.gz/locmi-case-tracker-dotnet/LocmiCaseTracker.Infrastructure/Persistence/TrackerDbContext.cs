using System.Text.Json;
using LocmiCaseTracker.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace LocmiCaseTracker.Infrastructure.Persistence;

public sealed class TrackerDbContext(DbContextOptions<TrackerDbContext> options) : DbContext(options)
{
    public DbSet<TrackerStateEntity> TrackerStates => Set<TrackerStateEntity>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var stringListConverter = new ValueConverter<List<string>, string>(
            value => JsonSerializer.Serialize(value, JsonOptions.Default),
            value => JsonSerializer.Deserialize<List<string>>(value, JsonOptions.Default) ?? new List<string>());
        var stringListComparer = JsonOptions.CreateJsonListComparer<string>();

        var stageListConverter = new ValueConverter<List<CategoryStageState>, string>(
            value => JsonSerializer.Serialize(value, JsonOptions.Default),
            value => JsonSerializer.Deserialize<List<CategoryStageState>>(value, JsonOptions.Default) ?? new List<CategoryStageState>());
        var stageListComparer = JsonOptions.CreateJsonListComparer<CategoryStageState>();

        var registryConverter = new ValueConverter<List<SourceRegistryRecord>, string>(
            value => JsonSerializer.Serialize(value, JsonOptions.Default),
            value => JsonSerializer.Deserialize<List<SourceRegistryRecord>>(value, JsonOptions.Default) ?? new List<SourceRegistryRecord>());
        var registryComparer = JsonOptions.CreateJsonListComparer<SourceRegistryRecord>();

        var rowConverter = new ValueConverter<List<CaseRow>, string>(
            value => JsonSerializer.Serialize(value, JsonOptions.Default),
            value => JsonSerializer.Deserialize<List<CaseRow>>(value, JsonOptions.Default) ?? new List<CaseRow>());
        var rowComparer = JsonOptions.CreateJsonListComparer<CaseRow>();

        modelBuilder.Entity<TrackerStateEntity>(entity =>
        {
            entity.ToTable("TrackerStates");
            entity.HasKey(x => x.Id);
            entity.Property(x => x.RowsJson).HasColumnType("TEXT");
            entity.Property(x => x.UpdatedAtUtc);
        });

        modelBuilder.Entity<TrackerStateEntity>().OwnsOne(x => x.State, owned =>
        {
            owned.Property(x => x.Rows)
                .HasConversion(rowConverter)
                .Metadata.SetValueComparer(rowComparer);
            owned.Property(x => x.Rows)
                .HasColumnName("Rows")
                .HasColumnType("TEXT");

            owned.OwnsOne(x => x.ItAdminConfig, admin =>
            {
                admin.Property(x => x.SourceRegistry)
                    .HasConversion(registryConverter)
                    .Metadata.SetValueComparer(registryComparer);
                admin.Property(x => x.SourceRegistry)
                    .HasColumnName("SourceRegistry")
                    .HasColumnType("TEXT");

                admin.Property(x => x.SyncFrequency).HasColumnName("SyncFrequency");
                admin.Property(x => x.Notes).HasColumnName("Notes");

                admin.OwnsOne(x => x.FrontlineConnection, connection =>
                {
                    connection.Property(x => x.Endpoint).HasColumnName("FrontlineEndpoint");
                    connection.Property(x => x.AuthType).HasColumnName("FrontlineAuthType");
                    connection.Property(x => x.AuthToken).HasColumnName("FrontlineAuthToken");
                    connection.Property(x => x.ApiKeyHeader).HasColumnName("FrontlineApiKeyHeader");
                    connection.Property(x => x.CaseNumberParam).HasColumnName("FrontlineCaseNumberParam");
                });
            });
        });
    }
}

public sealed class TrackerStateEntity
{
    public int Id { get; set; } = 1;
    public TrackerState State { get; set; } = new();
    public string RowsJson { get; set; } = string.Empty;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}

internal static class JsonOptions
{
    public static readonly JsonSerializerOptions Default = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true
    };

    public static ValueComparer<List<T>> CreateJsonListComparer<T>() where T : class
        => new(
            (left, right) => JsonSerializer.Serialize(left ?? new List<T>(), Default) == JsonSerializer.Serialize(right ?? new List<T>(), Default),
            value => JsonSerializer.Serialize(value ?? new List<T>(), Default).GetHashCode(),
            value => JsonSerializer.Deserialize<List<T>>(JsonSerializer.Serialize(value ?? new List<T>(), Default), Default) ?? new List<T>());
}
