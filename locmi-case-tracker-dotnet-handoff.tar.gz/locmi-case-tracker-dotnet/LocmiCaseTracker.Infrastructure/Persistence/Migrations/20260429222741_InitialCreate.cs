﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LocmiCaseTracker.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TrackerStates",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false),
                    Rows = table.Column<string>(type: "TEXT", nullable: false),
                    SourceRegistry = table.Column<string>(type: "TEXT", nullable: false),
                    SyncFrequency = table.Column<string>(type: "TEXT", nullable: false),
                    Notes = table.Column<string>(type: "TEXT", nullable: false),
                    FrontlineEndpoint = table.Column<string>(type: "TEXT", nullable: false),
                    FrontlineAuthType = table.Column<string>(type: "TEXT", nullable: false),
                    FrontlineAuthToken = table.Column<string>(type: "TEXT", nullable: false),
                    FrontlineApiKeyHeader = table.Column<string>(type: "TEXT", nullable: false),
                    FrontlineCaseNumberParam = table.Column<string>(type: "TEXT", nullable: false),
                    RowsJson = table.Column<string>(type: "TEXT", nullable: false),
                    UpdatedAtUtc = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TrackerStates", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TrackerStates");
        }
    }
}
