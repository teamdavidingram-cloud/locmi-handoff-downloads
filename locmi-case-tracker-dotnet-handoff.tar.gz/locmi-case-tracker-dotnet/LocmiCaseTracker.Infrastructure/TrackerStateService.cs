using System.Text;
using System.Text.Json;
using LocmiCaseTracker.Application.Contracts;
using LocmiCaseTracker.Domain;

namespace LocmiCaseTracker.Infrastructure;

public sealed class TrackerStateService(HttpClient httpClient) : ITrackerStateService
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true
    };

    private readonly HttpClient _httpClient = httpClient;

    public async Task<TrackerState> GetStateAsync(CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.GetAsync("api/state", cancellationToken);
        response.EnsureSuccessStatusCode();
        return await ReadJsonAsync<TrackerState>(response, cancellationToken) ?? new TrackerState();
    }

    public async Task<TrackerState> SaveStateAsync(TrackerState state, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.PutAsync(
            "api/state",
            new StringContent(JsonSerializer.Serialize(state, JsonOptions), Encoding.UTF8, "application/json"),
            cancellationToken);

        response.EnsureSuccessStatusCode();
        var wrapped = await ReadJsonAsync<SaveStateResponse>(response, cancellationToken);
        return wrapped?.State ?? state;
    }

    public Task<FrontlineLookupResult> TestFrontlineAsync(string caseNumber, CancellationToken cancellationToken = default)
        => PostFrontlineAsync("api/frontline/test", caseNumber, cancellationToken);

    public Task<FrontlineLookupResult> PreviewFrontlineAsync(string caseNumber, CancellationToken cancellationToken = default)
        => PostFrontlineAsync("api/frontline/preview", caseNumber, cancellationToken);

    public Task<FrontlineLookupResult> ApplyFrontlineAsync(string caseNumber, CancellationToken cancellationToken = default)
        => PostFrontlineAsync("api/frontline/apply", caseNumber, cancellationToken);

    private async Task<FrontlineLookupResult> PostFrontlineAsync(string path, string caseNumber, CancellationToken cancellationToken)
    {
        var payload = new StringContent(JsonSerializer.Serialize(new { caseNumber }, JsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.PostAsync(path, payload, cancellationToken);
        var result = await ReadJsonAsync<FrontlineLookupResult>(response, cancellationToken) ?? new FrontlineLookupResult();
        result.Ok = response.IsSuccessStatusCode && result.Ok;
        return result;
    }

    private static async Task<T?> ReadJsonAsync<T>(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        return await JsonSerializer.DeserializeAsync<T>(stream, JsonOptions, cancellationToken);
    }

    private sealed class SaveStateResponse
    {
        public bool Ok { get; set; }
        public TrackerState? State { get; set; }
    }
}
