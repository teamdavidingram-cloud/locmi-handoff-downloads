using LocmiCaseTracker.Application.Contracts;
using LocmiCaseTracker.Domain;
using LocmiCaseTracker.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace LocmiCaseTracker.Infrastructure;

public sealed class NativeTrackerStateService(TrackerDbContext dbContext) : ITrackerStateService
{
    private readonly TrackerDbContext _dbContext = dbContext;

    public async Task<TrackerState> GetStateAsync(CancellationToken cancellationToken = default)
    {
        var entity = await EnsureStateAsync(cancellationToken);
        return entity.State;
    }

    public async Task<TrackerState> SaveStateAsync(TrackerState state, CancellationToken cancellationToken = default)
    {
        var entity = await EnsureStateAsync(cancellationToken);
        entity.State = NormalizeState(state);
        entity.UpdatedAtUtc = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(cancellationToken);
        return entity.State;
    }

    public async Task<FrontlineLookupResult> TestFrontlineAsync(string caseNumber, CancellationToken cancellationToken = default)
    {
        try
        {
            var state = await GetStateAsync(cancellationToken);
            var resolved = ResolveSourceRecord(state, caseNumber);
            return new FrontlineLookupResult
            {
                Ok = true,
                Mode = resolved.Mode,
                CaseNumber = resolved.Record.CaseNumber,
                SourceRecord = resolved.Record
            };
        }
        catch (Exception ex)
        {
            return new FrontlineLookupResult { Ok = false, Error = ex.Message };
        }
    }

    public async Task<FrontlineLookupResult> PreviewFrontlineAsync(string caseNumber, CancellationToken cancellationToken = default)
    {
        try
        {
            var state = await GetStateAsync(cancellationToken);
            var resolved = ResolveSourceRecord(state, caseNumber);
            var existing = state.Rows.FirstOrDefault(row => SameCase(row.CaseNumber, resolved.Record.CaseNumber));
            var preview = BuildRowFromSourceRecord(resolved.Record, existing);
            return new FrontlineLookupResult
            {
                Ok = true,
                Mode = resolved.Mode,
                CaseNumber = resolved.Record.CaseNumber,
                SourceRecord = resolved.Record,
                PreviewRow = preview
            };
        }
        catch (Exception ex)
        {
            return new FrontlineLookupResult { Ok = false, Error = ex.Message };
        }
    }

    public async Task<FrontlineLookupResult> ApplyFrontlineAsync(string caseNumber, CancellationToken cancellationToken = default)
    {
        try
        {
            var entity = await EnsureStateAsync(cancellationToken);
            var state = entity.State;
            var resolved = ResolveSourceRecord(state, caseNumber);
            var existing = state.Rows.FirstOrDefault(row => SameCase(row.CaseNumber, resolved.Record.CaseNumber));
            var nextRow = BuildRowFromSourceRecord(resolved.Record, existing);

            if (existing is not null)
            {
                state.Rows = state.Rows.Select(row => row.Id == existing.Id ? nextRow : row).ToList();
            }
            else
            {
                state.Rows.Insert(0, nextRow);
            }

            var registry = state.ItAdminConfig.SourceRegistry;
            var existingRegistry = registry.FirstOrDefault(record => SameCase(record.CaseNumber, resolved.Record.CaseNumber));
            if (existingRegistry is not null)
            {
                var index = registry.IndexOf(existingRegistry);
                registry[index] = ToRegistryRecord(resolved.Record);
            }
            else
            {
                registry.Insert(0, ToRegistryRecord(resolved.Record));
            }

            entity.State = NormalizeState(state);
            entity.UpdatedAtUtc = DateTime.UtcNow;
            await _dbContext.SaveChangesAsync(cancellationToken);

            return new FrontlineLookupResult
            {
                Ok = true,
                Mode = resolved.Mode,
                CaseNumber = resolved.Record.CaseNumber,
                SourceRecord = resolved.Record,
                State = entity.State
            };
        }
        catch (Exception ex)
        {
            return new FrontlineLookupResult { Ok = false, Error = ex.Message };
        }
    }

    private async Task<TrackerStateEntity> EnsureStateAsync(CancellationToken cancellationToken)
    {
        var entity = await _dbContext.TrackerStates.FirstOrDefaultAsync(x => x.Id == 1, cancellationToken);
        if (entity is not null) return entity;

        entity = new TrackerStateEntity
        {
            Id = 1,
            State = SeedState(),
            UpdatedAtUtc = DateTime.UtcNow
        };

        _dbContext.TrackerStates.Add(entity);
        await _dbContext.SaveChangesAsync(cancellationToken);
        return entity;
    }

    private static TrackerState SeedState()
    {
        return new TrackerState
        {
            Rows =
            [
                new CaseRow
                {
                    Id = "1",
                    CaseNumber = "LC-24001",
                    ClientName = "Maria Santos",
                    CaseworkTeam = "Family",
                    Caseworker = "Tobias Falco",
                    RetentionDate = "2026-04-03",
                    Deadline = "2026-04-03",
                    RemainingDays = 2,
                    Os = "Family",
                    CrqMissingDocs = "Passport copy",
                    CrqStatus = "Blocked",
                    QuestionnaireStatus = "Waiting",
                    ApprovalStatus = "In Progress",
                    ArgumentStatus = "Waiting",
                    FinalMeritsStatus = "Pending",
                    CoverLetterStatus = "Pending",
                    CaseStatusReport = "Client documents still incomplete.",
                    Reminder = "Follow up today",
                    SelectedCategories = ["Category A", "Category B", "Category C"],
                    StageBreakdown =
                    [
                        new CategoryStageState { Category = "Category A", Questionnaire = "Completed", Approval = "Completed", Arguments = "In Progress" },
                        new CategoryStageState { Category = "Category B", Questionnaire = "Blocked", Approval = "Waiting", Arguments = "Waiting" },
                        new CategoryStageState { Category = "Category C", Questionnaire = "Waiting", Approval = "Waiting", Arguments = "Waiting" }
                    ]
                },
                new CaseRow
                {
                    Id = "2",
                    CaseNumber = "LC-24002",
                    ClientName = "Daniel Reed",
                    CaseworkTeam = "Civil",
                    Caseworker = "Daiana Bernini",
                    RetentionDate = "2026-04-09",
                    Deadline = "2026-04-09",
                    RemainingDays = 6,
                    Os = "Civil",
                    CrqMissingDocs = "None",
                    CrqStatus = "Completed",
                    QuestionnaireStatus = "Completed",
                    ApprovalStatus = "In Progress",
                    ArgumentStatus = "In Progress",
                    FinalMeritsStatus = "Draft complete",
                    CoverLetterStatus = "In progress",
                    CaseStatusReport = "Ready for next review window.",
                    Reminder = "Check argument review",
                    SelectedCategories = ["Category A", "Category B"],
                    StageBreakdown =
                    [
                        new CategoryStageState { Category = "Category A", Questionnaire = "Completed", Approval = "Completed", Arguments = "Completed" },
                        new CategoryStageState { Category = "Category B", Questionnaire = "Completed", Approval = "In Progress", Arguments = "In Progress" }
                    ]
                }
            ],
            ItAdminConfig = new ITAdminConfig
            {
                SourceRegistry =
                [
                    new SourceRegistryRecord
                    {
                        Id = "registry-1",
                        CaseNumber = "LC-24001",
                        ClientName = "Maria Santos",
                        OnboardingSpecialist = "Family",
                        Caseworker = "Tobias Falco",
                        RetainedDate = "2026-04-03",
                        Categories = ["Category A", "Category B", "Category C"]
                    },
                    new SourceRegistryRecord
                    {
                        Id = "registry-2",
                        CaseNumber = "LC-24002",
                        ClientName = "Daniel Reed",
                        OnboardingSpecialist = "Civil",
                        Caseworker = "Daiana Bernini",
                        RetainedDate = "2026-04-09",
                        Categories = ["Category A", "Category B"]
                    }
                ]
            }
        };
    }

    private static TrackerState NormalizeState(TrackerState state)
    {
        state.ItAdminConfig ??= new ITAdminConfig();
        state.ItAdminConfig.FrontlineConnection ??= new FrontlineConnectionConfig();
        state.ItAdminConfig.SourceRegistry ??= [];
        state.Rows ??= [];
        return state;
    }

    private static (string Mode, FrontlineSourceRecord Record) ResolveSourceRecord(TrackerState state, string caseNumber)
    {
        var normalized = caseNumber?.Trim();
        if (string.IsNullOrWhiteSpace(normalized)) throw new InvalidOperationException("Case Number is required");

        var registry = state.ItAdminConfig.SourceRegistry.FirstOrDefault(record => SameCase(record.CaseNumber, normalized));
        if (registry is not null)
        {
            return ("local-fallback", new FrontlineSourceRecord
            {
                Id = registry.Id,
                CaseNumber = registry.CaseNumber,
                ClientName = registry.ClientName,
                OnboardingSpecialist = registry.OnboardingSpecialist,
                Caseworker = registry.Caseworker,
                RetainedDate = registry.RetainedDate,
                Categories = registry.Categories
            });
        }

        var row = state.Rows.FirstOrDefault(existing => SameCase(existing.CaseNumber, normalized));
        if (row is not null)
        {
            return ("local-fallback", new FrontlineSourceRecord
            {
                Id = row.Id,
                CaseNumber = row.CaseNumber,
                ClientName = row.ClientName,
                OnboardingSpecialist = row.Os,
                Caseworker = row.Caseworker,
                RetainedDate = row.RetentionDate,
                Categories = row.SelectedCategories.Count > 0 ? row.SelectedCategories : ["Category A"]
            });
        }

        throw new InvalidOperationException("No matching source record found for that Case Number");
    }

    private static CaseRow BuildRowFromSourceRecord(FrontlineSourceRecord record, CaseRow? existing)
    {
        var categories = record.Categories.Count > 0 ? record.Categories : ["Category A"];
        return new CaseRow
        {
            Id = existing?.Id ?? record.Id ?? $"frontline-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}",
            CaseNumber = record.CaseNumber,
            ClientName = record.ClientName,
            Caseworker = record.Caseworker,
            RetentionDate = record.RetainedDate,
            Deadline = record.RetainedDate,
            RemainingDays = CalculateRemainingDays(record.RetainedDate),
            Os = record.OnboardingSpecialist,
            CaseworkTeam = record.OnboardingSpecialist,
            CrqMissingDocs = existing?.CrqMissingDocs ?? "None",
            CrqStatus = existing?.CrqStatus ?? "Waiting",
            QuestionnaireStatus = existing?.QuestionnaireStatus ?? "Status",
            ApprovalStatus = existing?.ApprovalStatus ?? "Status",
            ArgumentStatus = existing?.ArgumentStatus ?? "Status",
            FinalMeritsStatus = existing?.FinalMeritsStatus ?? "Pending",
            CoverLetterStatus = existing?.CoverLetterStatus ?? "Pending",
            CaseStatusReport = existing?.CaseStatusReport ?? string.Empty,
            Reminder = existing?.Reminder ?? "Review case",
            SelectedCategories = categories,
            StageBreakdown = categories.Select(category => existing?.StageBreakdown.FirstOrDefault(item => item.Category == category) ?? new CategoryStageState
            {
                Category = category,
                Questionnaire = "Waiting",
                Approval = "Waiting",
                Arguments = "Waiting",
                ArgumentSupervisorDecision = string.Empty,
                ArgumentSupervisorFeedback = string.Empty
            }).ToList()
        };
    }

    private static SourceRegistryRecord ToRegistryRecord(FrontlineSourceRecord record)
        => new()
        {
            Id = record.Id,
            CaseNumber = record.CaseNumber,
            ClientName = record.ClientName,
            OnboardingSpecialist = record.OnboardingSpecialist,
            Caseworker = record.Caseworker,
            RetainedDate = record.RetainedDate,
            Categories = record.Categories
        };

    private static int CalculateRemainingDays(string retainedDate)
    {
        if (!DateOnly.TryParse(retainedDate, out var retained)) return 75;
        var target = retained.AddDays(75);
        return target.DayNumber - DateOnly.FromDateTime(DateTime.Today).DayNumber;
    }

    private static bool SameCase(string? left, string? right)
        => string.Equals(left?.Trim(), right?.Trim(), StringComparison.OrdinalIgnoreCase);
}
