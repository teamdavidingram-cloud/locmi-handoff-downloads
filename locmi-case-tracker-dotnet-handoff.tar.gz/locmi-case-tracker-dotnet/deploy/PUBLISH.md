# LOCMI Case Tracker .NET Publish & Service Notes

## Publish

```bash
cd /home/ingramlaw/projects/lock-project/locmi-case-tracker-dotnet
dotnet publish LocmiCaseTracker.Api/LocmiCaseTracker.Api.csproj -c Release
```

Published output:
- `LocmiCaseTracker.Api/bin/Release/net8.0/publish/`

The API project is the main deployment artifact because it hosts the Blazor web client.

## Run locally

```bash
cd /home/ingramlaw/projects/lock-project/locmi-case-tracker-dotnet
dotnet run --project LocmiCaseTracker.Api/LocmiCaseTracker.Api.csproj --urls http://127.0.0.1:5310
```

## Data location

SQLite database is created at:
- `LocmiCaseTracker.Api/App_Data/locmi-case-tracker.db`

## systemd

Sample unit file included:
- `deploy/locmi-case-tracker-dotnet.service`
