using LocmiCaseTracker.Application.Contracts;
using LocmiCaseTracker.Domain;
using LocmiCaseTracker.Infrastructure;
using LocmiCaseTracker.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options =>
{
    options.AddPolicy("Default", policy =>
        policy.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
});

var dataDirectory = Path.Combine(builder.Environment.ContentRootPath, "App_Data");
Directory.CreateDirectory(dataDirectory);
var databasePath = Path.Combine(dataDirectory, "locmi-case-tracker.db");

builder.Services.AddDbContext<TrackerDbContext>(options =>
    options.UseSqlite($"Data Source={databasePath}"));
builder.Services.AddScoped<ITrackerStateService, NativeTrackerStateService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<TrackerDbContext>();
    dbContext.Database.Migrate();
}

app.UseCors("Default");
app.UseHttpsRedirection();

app.UseBlazorFrameworkFiles();
app.UseStaticFiles();

app.MapGet("/api/health", () => Results.Ok(new
{
    ok = true,
    service = "locmi-case-tracker-dotnet",
    mode = "native",
    timestamp = DateTime.UtcNow
}));

app.MapGet("/api/state", async (ITrackerStateService trackerStateService, CancellationToken cancellationToken) =>
{
    var state = await trackerStateService.GetStateAsync(cancellationToken);
    return Results.Ok(state);
});

app.MapPut("/api/state", async (TrackerState state, ITrackerStateService trackerStateService, CancellationToken cancellationToken) =>
{
    var saved = await trackerStateService.SaveStateAsync(state, cancellationToken);
    return Results.Ok(new { ok = true, state = saved });
});

app.MapPost("/api/frontline/test", async (CaseNumberRequest request, ITrackerStateService trackerStateService, CancellationToken cancellationToken) =>
{
    var result = await trackerStateService.TestFrontlineAsync(request.CaseNumber ?? string.Empty, cancellationToken);
    return result.Ok ? Results.Ok(result) : Results.BadRequest(result);
});

app.MapPost("/api/frontline/preview", async (CaseNumberRequest request, ITrackerStateService trackerStateService, CancellationToken cancellationToken) =>
{
    var result = await trackerStateService.PreviewFrontlineAsync(request.CaseNumber ?? string.Empty, cancellationToken);
    return result.Ok ? Results.Ok(result) : Results.BadRequest(result);
});

app.MapPost("/api/frontline/apply", async (CaseNumberRequest request, ITrackerStateService trackerStateService, CancellationToken cancellationToken) =>
{
    var result = await trackerStateService.ApplyFrontlineAsync(request.CaseNumber ?? string.Empty, cancellationToken);
    return result.Ok ? Results.Ok(result) : Results.BadRequest(result);
});

app.MapFallbackToFile("index.html");

app.Run();

public sealed record CaseNumberRequest(string? CaseNumber);
