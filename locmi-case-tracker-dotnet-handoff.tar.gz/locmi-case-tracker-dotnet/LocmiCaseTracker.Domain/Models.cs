namespace LocmiCaseTracker.Domain;

public enum UserRole
{
    Admin,
    TeamLead,
    Caseworker
}

public enum StageStatus
{
    Waiting,
    InProgress,
    Completed,
    Blocked
}

public enum FrontlineAuthType
{
    None,
    Bearer,
    ApiKey
}

public sealed class CaseRow
{
    public string Id { get; set; } = string.Empty;
    public string CaseNumber { get; set; } = string.Empty;
    public string ClientName { get; set; } = string.Empty;
    public string CaseworkTeam { get; set; } = string.Empty;
    public string Caseworker { get; set; } = string.Empty;
    public string RetentionDate { get; set; } = string.Empty;
    public string Deadline { get; set; } = string.Empty;
    public int RemainingDays { get; set; }
    public string Os { get; set; } = string.Empty;
    public string CrqMissingDocs { get; set; } = string.Empty;
    public string CrqStatus { get; set; } = string.Empty;
    public string QuestionnaireStatus { get; set; } = string.Empty;
    public string ApprovalStatus { get; set; } = string.Empty;
    public string ArgumentStatus { get; set; } = string.Empty;
    public string FinalMeritsStatus { get; set; } = string.Empty;
    public string CoverLetterStatus { get; set; } = string.Empty;
    public string CaseStatusReport { get; set; } = string.Empty;
    public string Reminder { get; set; } = string.Empty;
    public List<string> SelectedCategories { get; set; } = new();
    public List<CategoryStageState> StageBreakdown { get; set; } = new();
}

public sealed class CategoryStageState
{
    public string Category { get; set; } = string.Empty;
    public string Questionnaire { get; set; } = string.Empty;
    public string Approval { get; set; } = string.Empty;
    public string Arguments { get; set; } = string.Empty;
    public string ArgumentSupervisorDecision { get; set; } = string.Empty;
    public string ArgumentSupervisorFeedback { get; set; } = string.Empty;
}

public sealed class SourceRegistryRecord
{
    public string Id { get; set; } = string.Empty;
    public string CaseNumber { get; set; } = string.Empty;
    public string ClientName { get; set; } = string.Empty;
    public string OnboardingSpecialist { get; set; } = string.Empty;
    public string Caseworker { get; set; } = string.Empty;
    public string RetainedDate { get; set; } = string.Empty;
    public List<string> Categories { get; set; } = new();
}

public sealed class FrontlineConnectionConfig
{
    public string Endpoint { get; set; } = string.Empty;
    public string AuthType { get; set; } = "none";
    public string AuthToken { get; set; } = string.Empty;
    public string ApiKeyHeader { get; set; } = "x-api-key";
    public string CaseNumberParam { get; set; } = "caseNumber";
}

public sealed class ITAdminConfig
{
    public List<SourceRegistryRecord> SourceRegistry { get; set; } = new();
    public string SyncFrequency { get; set; } = "Per case entry";
    public string Notes { get; set; } = "Frontline is the visible integration point for linking the main server to this tracker by Case Number.";
    public FrontlineConnectionConfig FrontlineConnection { get; set; } = new();
}

public sealed class TrackerState
{
    public List<CaseRow> Rows { get; set; } = new();
    public ITAdminConfig ItAdminConfig { get; set; } = new();
}

public sealed class FrontlineSourceRecord
{
    public string Id { get; set; } = string.Empty;
    public string CaseNumber { get; set; } = string.Empty;
    public string ClientName { get; set; } = string.Empty;
    public string OnboardingSpecialist { get; set; } = string.Empty;
    public string Caseworker { get; set; } = string.Empty;
    public string RetainedDate { get; set; } = string.Empty;
    public List<string> Categories { get; set; } = new();
}
