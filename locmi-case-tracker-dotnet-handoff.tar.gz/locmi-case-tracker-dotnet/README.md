# LOCMI Case Tracker .NET Handover

This folder contains the working .NET 8 rewrite workspace for the LOCMI Case Tracker project.

## Source Project

- Original project: `/home/ingramlaw/projects/locmi-case-tracker`
- Original stack: React + TypeScript frontend with separate API folder

## Rewrite Workspace

- Handover root: `/home/ingramlaw/projects/lock-project/locmi-case-tracker-dotnet`
- Solution: `LocmiCaseTracker.sln`

Projects inside the solution:
- `LocmiCaseTracker.Api` → ASP.NET Core API and hosted web delivery target
- `LocmiCaseTracker.Web` → Blazor WebAssembly tracker client
- `LocmiCaseTracker.Domain` → entities and workflow models
- `LocmiCaseTracker.Application` → service contracts
- `LocmiCaseTracker.Infrastructure` → EF Core persistence and tracker service logic

## Current Working Scope

The rewrite currently includes real .NET implementations for:
- tracker state load/save
- SQLite-backed persistence via EF Core
- Frontline test/preview/apply flows
- local source-registry fallback behavior
- spreadsheet-style tracker client
- summary panels and reminders view
- Frontline integration modal
- hosted single-app API + web packaging

## Verified API Behavior

Verified locally on `http://127.0.0.1:5310`:
- `GET /api/health`
- `GET /api/state`
- `POST /api/frontline/test`
- `POST /api/frontline/preview`
- `POST /api/frontline/apply`

## Build Verification

```bash
dotnet build LocmiCaseTracker.sln
```

Last verified result:
- Build succeeded
- `0 Warning(s)`
- `0 Error(s)`

## Database / Migration

Initial EF migration created under:
- `LocmiCaseTracker.Infrastructure/Persistence/Migrations/`

The API applies migrations on startup.

## Publish & Service Notes

See:
- `deploy/PUBLISH.md`
- `deploy/locmi-case-tracker-dotnet.service`

## Honest Status

This is now a real handoff-grade .NET rewrite with:
- native persistence and migrations
- hosted Blazor client served by the API publish artifact
- Frontline integration test/preview/apply workflow
- spreadsheet import support for CSV/XLSX/XLS with validation preview
- verified published runtime serving both the app shell and API routes

The remaining future work would be optional refinement rather than core completeness:
- richer explicit column-mapping UX if exact spreadsheet onboarding parity is required
- additional visual polish if pixel-level parity is needed
