using Lockme1Dashboard.Application.Contracts;
using Lockme1Dashboard.Application.Models;
using Microsoft.AspNetCore.Mvc;

namespace Lockme1Dashboard.Api.Controllers;

[ApiController]
[Route("api")]
public class DashboardController(IDashboardService dashboardService) : ControllerBase
{
    [HttpGet("dashboard")]
    public async Task<IActionResult> Dashboard([FromQuery] string? role, [FromQuery] string? range)
    {
        return Ok(await dashboardService.GetDashboardAsync(role ?? "leadership", range ?? "1m"));
    }

    [HttpPost("admin/patch")]
    public async Task<IActionResult> Patch([FromQuery] string? range, [FromBody] PatchRequest request)
    {
        return Ok(await dashboardService.ApplyPatchAsync(range ?? "1m", request));
    }

    [HttpGet("admin/audit")]
    public async Task<IActionResult> Audit()
    {
        return Ok(await dashboardService.GetAuditAsync());
    }

    [HttpGet("health")]
    public IActionResult Health() => Ok(new { ok = true, service = "lockme1-dashboard-dotnet", timestamp = DateTime.UtcNow });
}
