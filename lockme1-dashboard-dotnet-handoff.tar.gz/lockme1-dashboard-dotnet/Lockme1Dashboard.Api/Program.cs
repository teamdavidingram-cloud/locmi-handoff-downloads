using Lockme1Dashboard.Application.Contracts;
using Lockme1Dashboard.Infrastructure;
using Lockme1Dashboard.Infrastructure.Persistence;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddResponseCompression(options =>
{
    options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(new[] { "application/octet-stream" });
});

var dataDirectory = Path.Combine(builder.Environment.ContentRootPath, "App_Data");
Directory.CreateDirectory(dataDirectory);
var connectionString = builder.Configuration.GetConnectionString("Default")
    ?? $"Data Source={Path.Combine(dataDirectory, "lockme1-dashboard.db")}";

builder.Services.AddDbContext<Lockme1DashboardDbContext>(options => options.UseSqlite(connectionString));
builder.Services.AddScoped<IDashboardService, DashboardService>();
builder.Services.AddCors(options =>
{
    options.AddPolicy("App", policy => policy.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<Lockme1DashboardDbContext>();
    db.Database.Migrate();
}

app.UseResponseCompression();
app.UseSwagger();
app.UseSwaggerUI();
app.UseBlazorFrameworkFiles();
app.UseStaticFiles();
app.UseCors("App");
app.MapControllers();
app.MapFallbackToFile("index.html");
app.Run();
