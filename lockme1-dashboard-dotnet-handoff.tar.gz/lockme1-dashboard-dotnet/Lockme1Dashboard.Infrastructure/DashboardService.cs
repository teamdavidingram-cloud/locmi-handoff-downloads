using System.Text.Json;
using Lockme1Dashboard.Application.Contracts;
using Lockme1Dashboard.Application.Models;
using Lockme1Dashboard.Domain;
using Lockme1Dashboard.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Lockme1Dashboard.Infrastructure;

public class DashboardService(Lockme1DashboardDbContext dbContext) : IDashboardService
{
    private static readonly string[] MetricOrder =
    [
        "Total Live Cases",
        "RFEs",
        "Zombie Cases",
        "Refunds",
        "Noise",
        "Closed This Month",
        "Leads",
        "Referrals"
    ];

    private readonly Lockme1DashboardDbContext _db = dbContext;

    public async Task<DashboardResponseDto> GetDashboardAsync(string role, string range)
    {
        await EnsureSeedDataAsync();
        var metrics = await _db.DashboardMetrics.OrderBy(x => x.Id).ToListAsync();
        var drills = await _db.DrilldownRows.OrderBy(x => x.Id).ToListAsync();
        var meta = await _db.DashboardMeta.FirstAsync();
        var selectedRange = NormalizeRange(range);
        var scenario = BuildScenario(selectedRange, metrics, drills);
        return BuildDashboardResponse(role, selectedRange, scenario, metrics, meta, drills);
    }

    public async Task<DashboardResponseDto> ApplyPatchAsync(string range, PatchRequest request)
    {
        await EnsureSeedDataAsync();
        var metrics = await _db.DashboardMetrics.OrderBy(x => x.Id).ToListAsync();
        var oldValues = metrics.ToDictionary(x => x.Key, x => x.Value);
        var changed = new List<string>();

        foreach (var patch in request.Metrics)
        {
            var metric = metrics.FirstOrDefault(x => x.Key == patch.Key);
            if (metric is null || metric.Value == patch.Value) continue;
            metric.Value = patch.Value;
            metric.UpdatedAt = DateTime.UtcNow;
            changed.Add(metric.Key);
        }

        var meta = await _db.DashboardMeta.FirstAsync();
        meta.UpdatedAt = DateTime.UtcNow;
        meta.UpdatedBy = string.IsNullOrWhiteSpace(request.User) ? "admin" : request.User.Trim();

        if (changed.Count > 0)
        {
            var newValues = metrics.Where(x => changed.Contains(x.Key)).ToDictionary(x => x.Key, x => x.Value);
            _db.PatchAudits.Add(new PatchAudit
            {
                User = meta.UpdatedBy,
                ChangedFields = string.Join(", ", changed),
                OldValuesJson = JsonSerializer.Serialize(oldValues.Where(x => changed.Contains(x.Key)).ToDictionary()),
                NewValuesJson = JsonSerializer.Serialize(newValues)
            });
        }

        await _db.SaveChangesAsync();
        return await GetDashboardAsync("admin", range);
    }

    public async Task<List<AuditRowDto>> GetAuditAsync()
    {
        await EnsureSeedDataAsync();
        return await _db.PatchAudits
            .OrderByDescending(x => x.Timestamp)
            .Select(x => new AuditRowDto(x.Id, x.Timestamp.ToString("O"), x.User, x.ChangedFields, x.OldValuesJson, x.NewValuesJson))
            .ToListAsync();
    }

    private async Task EnsureSeedDataAsync()
    {
        if (await _db.DashboardMetrics.AnyAsync()) return;

        _db.DashboardMeta.Add(new DashboardMeta { UpdatedBy = "developer" });
        foreach (var metric in SeedMetrics()) _db.DashboardMetrics.Add(metric);
        foreach (var row in SeedDrillData()) _db.DrilldownRows.Add(row);
        await _db.SaveChangesAsync();
    }

    private DashboardResponseDto BuildDashboardResponse(string role, string range, Scenario scenario, List<DashboardMetric> baseMetrics, DashboardMeta meta, List<DrilldownRow> baseDrills)
    {
        var scoredMetrics = scenario.Metrics.Select(MapMetric).ToList();
        var score = scenario.Metrics.Sum(x => ScoreStatus(x.Status));
        var overall = score >= 12 ? "green" : score >= 7 ? "amber" : "red";
        var summary = BuildSummary(range, scenario, scoredMetrics, score);
        var drillData = MetricOrder.ToDictionary(
            key => key,
            key => (scenario.DrillData.TryGetValue(key, out var rows) ? rows : [])
                .Select(r => new DrillRowDto(r.Ref, r.Client, r.Status, r.Activity, r.Owner))
                .ToList());

        return new DashboardResponseDto(
            NormalizeRole(role),
            range,
            [new("today", "Today"), new("yesterday", "Yesterday"), new("7d", "7 days"), new("1m", "This month")],
            new DashboardStateDto(baseMetrics.OrderBy(x => Array.IndexOf(MetricOrder, x.Key)).Select(ToPatchMetricDto).ToList(), meta.UpdatedAt.ToString("O"), meta.UpdatedBy),
            new AnalysisDto(score, overall, summary.Brief, scoredMetrics, summary),
            drillData,
            true);
    }

    private static PatchMetricDto ToPatchMetricDto(DashboardMetric metric) => new(metric.Key, metric.Label, metric.Value, metric.Prior, metric.Note, ToDirection(metric.Direction), JsonSerializer.Deserialize<List<int>>(metric.SparkJson) ?? []);
    private static MetricDto MapMetric(ScenarioMetric metric) => new(metric.Key, metric.Label, metric.Value, metric.Prior, metric.Note, ToDirection(metric.Direction), metric.Spark, metric.Status.ToString().ToLowerInvariant());
    private static string ToDirection(MetricDirection direction) => direction == MetricDirection.HigherBetter ? "higher-better" : "lower-better";
    private static string NormalizeRole(string role) => role.Trim().ToLowerInvariant() switch { "admin" => "admin", "developer" => "developer", _ => "leadership" };
    private static string NormalizeRange(string range) => range.Trim().ToLowerInvariant() switch { "today" => "today", "yesterday" => "yesterday", "7d" => "7d", _ => "1m" };
    private static int ScoreStatus(KpiStatus status) => status == KpiStatus.Green ? 2 : status == KpiStatus.Amber ? 1 : 0;

    private static SummaryCardDto BuildSummary(string range, Scenario scenario, List<MetricDto> metrics, int score)
    {
        var overall = score >= 12 ? "green" : score >= 7 ? "amber" : "red";
        var red = metrics.Where(x => x.Status == "red").Select(x => x.Label).ToList();
        var amber = metrics.Where(x => x.Status == "amber").Select(x => x.Label).ToList();
        var zombie = scenario.DrillData["Zombie Cases"];
        var active = zombie.Count(x => x.Status.Contains("Active", StringComparison.OrdinalIgnoreCase));
        var nonActive = zombie.Count - active;
        var brief = overall switch
        {
            "green" => $"LOCMI 1 is healthy for {scenario.Label.ToLowerInvariant()}.",
            "amber" => $"LOCMI 1 is under pressure for {scenario.Label.ToLowerInvariant()}, driven by live cases and stale work.",
            _ => $"LOCMI 1 is at risk for {scenario.Label.ToLowerInvariant()}, with material KPI pressure."
        };

        var bullets = new List<string>
        {
            $"{scenario.Label}: LOCMI 1 is {(overall == "green" ? "Healthy" : overall == "amber" ? "Under Pressure" : "At Risk")} at {score}/16, compared with {scenario.ComparisonLabel}.",
            $"Zombie cases break down into {active} active stale matters and {nonActive} parked matters in this selected range.",
        };
        if (red.Count > 0) bullets.Add($"Immediate attention: {string.Join(", ", red)}.");
        if (amber.Count > 0) bullets.Add($"Watch list: {string.Join(", ", amber)}.");

        return new SummaryCardDto(range, scenario.Label, scenario.ComparisonLabel, overall == "green" ? $"Healthy {scenario.Label}" : overall == "amber" ? $"Under Pressure {scenario.Label}" : $"At Risk {scenario.Label}", brief, bullets, new ZombieBreakdownDto(active, nonActive, zombie.Count), scenario.Metrics.Where(x => x.Status != KpiStatus.Green).Select(x => x.Label).Take(3).ToList());
    }

    private static Scenario BuildScenario(string range, List<DashboardMetric> metrics, List<DrilldownRow> drills)
    {
        var baseMetrics = metrics.Select(m => new ScenarioMetric(m.Key, m.Label, m.Value, m.Prior, m.Note, m.Direction, JsonSerializer.Deserialize<List<int>>(m.SparkJson) ?? [], ScoreMetric(m.Key, m.Value))).ToList();
        var drillMap = MetricOrder.ToDictionary(k => k, k => drills.Where(d => d.MetricKey == k).Select(x => new ScenarioDrill(x.Ref, x.Client, x.Status, x.Activity, x.Owner)).ToList());
        return range switch
        {
            "today" => ApplyAdjustments("Today", "yesterday", baseMetrics, drillMap, new Dictionary<string, (int value, int prior, string note)>
            {
                ["Total Live Cases"] = (182, 184, "Two cases closed today, live load slightly down."),
                ["RFEs"] = (3, 5, "Only three RFEs opened today, intake pressure controlled."),
                ["Zombie Cases"] = (6, 7, "One zombie case reactivated today, six still active and stale."),
                ["Refunds"] = (1, 0, "A same-day refund request has landed and needs review."),
                ["Noise"] = (4, 6, "Noise filtered down after tighter intake tagging."),
                ["Closed This Month"] = (2, 1, "Two matters closed today versus one yesterday."),
                ["Leads"] = (6, 4, "Lead generation is stronger than yesterday morning."),
                ["Referrals"] = (2, 1, "Two referral matters came in today."),
            }),
            "yesterday" => ApplyAdjustments("Yesterday", "prior day", baseMetrics, drillMap, new Dictionary<string, (int value, int prior, string note)>
            {
                ["Total Live Cases"] = (184, 186, "Yesterday closed the day with a slightly heavier live load."),
                ["RFEs"] = (5, 4, "RFE volume rose yesterday afternoon."),
                ["Zombie Cases"] = (7, 6, "Aged active cases increased by one yesterday."),
                ["Refunds"] = (0, 1, "No refunds were triggered yesterday."),
                ["Noise"] = (6, 8, "Noise improved versus the prior day, but remained elevated."),
                ["Closed This Month"] = (1, 2, "Only one matter closed yesterday."),
                ["Leads"] = (4, 5, "Lead flow eased off versus the prior day."),
                ["Referrals"] = (1, 2, "Referral intake was modest yesterday."),
            }),
            "7d" => ApplyAdjustments("Last 7 days", "previous 7 days", baseMetrics, drillMap, new Dictionary<string, (int value, int prior, string note)>
            {
                ["Total Live Cases"] = (184, 176, "Live book rose by eight matters against the prior seven days."),
                ["RFEs"] = (8, 5, "RFE accumulation is accelerating week on week."),
                ["Zombie Cases"] = (7, 4, "Three additional matters aged into zombie status this week."),
                ["Refunds"] = (3, 1, "Refunds tripled compared with the prior seven-day window."),
                ["Noise"] = (11, 8, "Unqualified inbound volume is back up over the last week."),
                ["Closed This Month"] = (9, 11, "Closures are trailing the previous seven-day pace."),
                ["Leads"] = (24, 19, "Lead generation stayed strong over the week."),
                ["Referrals"] = (9, 6, "Referral matters improved across the week."),
            }),
            _ => ApplyAdjustments("This month", "prior month", baseMetrics, drillMap, new Dictionary<string, (int value, int prior, string note)>
            {
                ["Total Live Cases"] = (184, 161, "Live cases are materially above last month, indicating slower exits than intake."),
                ["RFEs"] = (8, 4, "RFE workload has doubled compared with last month."),
                ["Zombie Cases"] = (7, 2, "Zombie cases climbed sharply month on month."),
                ["Refunds"] = (3, 1, "Refund pressure is materially higher than last month."),
                ["Noise"] = (11, 9, "Noise is higher month on month, suggesting poorer qualification upstream."),
                ["Closed This Month"] = (9, 13, "Closures are down four against last month."),
                ["Leads"] = (24, 18, "Lead generation is stronger than last month."),
                ["Referrals"] = (9, 5, "Referrals are materially ahead of last month."),
            })
        };
    }

    private static Scenario ApplyAdjustments(string label, string comparisonLabel, List<ScenarioMetric> baseMetrics, Dictionary<string, List<ScenarioDrill>> baseDrill, Dictionary<string, (int value, int prior, string note)> updates)
    {
        var metrics = baseMetrics.Select(m => m with { Spark = [..m.Spark] }).ToList();
        foreach (var metric in metrics)
        {
            if (!updates.TryGetValue(metric.Key, out var update)) continue;
            metric.Value = update.value;
            metric.Prior = update.prior;
            metric.Note = update.note;
            if (metric.Spark.Count > 0) metric.Spark[^1] = metric.Value;
            metric.Status = ScoreMetric(metric.Key, metric.Value);
        }
        return new Scenario(label, comparisonLabel, metrics, baseDrill.ToDictionary(x => x.Key, x => x.Value.Select(v => v with { }).ToList()));
    }

    private static KpiStatus ScoreMetric(string key, int value) => key switch
    {
        "Total Live Cases" => value < 150 ? KpiStatus.Green : value <= 199 ? KpiStatus.Amber : KpiStatus.Red,
        "RFEs" => value < 5 ? KpiStatus.Green : value <= 9 ? KpiStatus.Amber : KpiStatus.Red,
        "Zombie Cases" => value <= 2 ? KpiStatus.Green : value <= 6 ? KpiStatus.Amber : KpiStatus.Red,
        "Refunds" => value <= 1 ? KpiStatus.Green : value <= 3 ? KpiStatus.Amber : KpiStatus.Red,
        "Noise" => value <= 5 ? KpiStatus.Green : value <= 12 ? KpiStatus.Amber : KpiStatus.Red,
        "Closed This Month" => value > 12 ? KpiStatus.Green : value >= 7 ? KpiStatus.Amber : KpiStatus.Red,
        "Leads" => value > 20 ? KpiStatus.Green : value >= 10 ? KpiStatus.Amber : KpiStatus.Red,
        "Referrals" => value > 8 ? KpiStatus.Green : value >= 4 ? KpiStatus.Amber : KpiStatus.Red,
        _ => KpiStatus.Amber
    };

    private static List<DashboardMetric> SeedMetrics() =>
    [
        new() { Key = "Total Live Cases", Label = "Total Live Cases", Value = 184, Prior = 176, Note = "Firm capacity watch level", Direction = MetricDirection.LowerBetter, SparkJson = JsonSerializer.Serialize(new[] { 155, 162, 168, 171, 176, 184 }) },
        new() { Key = "RFEs", Label = "RFEs", Value = 8, Prior = 7, Note = "Approaching concern level", Direction = MetricDirection.LowerBetter, SparkJson = JsonSerializer.Serialize(new[] { 3, 4, 5, 6, 7, 8 }) },
        new() { Key = "Zombie Cases", Label = "Zombie Cases", Value = 7, Prior = 5, Note = "Immediate review required", Direction = MetricDirection.LowerBetter, SparkJson = JsonSerializer.Serialize(new[] { 1, 2, 3, 4, 5, 7 }) },
        new() { Key = "Refunds", Label = "Refunds", Value = 3, Prior = 2, Note = "Client dissatisfaction signal", Direction = MetricDirection.LowerBetter, SparkJson = JsonSerializer.Serialize(new[] { 0, 1, 1, 2, 2, 3 }) },
        new() { Key = "Noise", Label = "Noise", Value = 11, Prior = 12, Note = "Filtering improving but still elevated", Direction = MetricDirection.LowerBetter, SparkJson = JsonSerializer.Serialize(new[] { 14, 13, 15, 14, 12, 11 }) },
        new() { Key = "Closed This Month", Label = "Closed This Month", Value = 9, Prior = 8, Note = "Throughput stable but not strong", Direction = MetricDirection.HigherBetter, SparkJson = JsonSerializer.Serialize(new[] { 6, 7, 7, 8, 8, 9 }) },
        new() { Key = "Leads", Label = "Leads", Value = 24, Prior = 20, Note = "Healthy enquiry growth", Direction = MetricDirection.HigherBetter, SparkJson = JsonSerializer.Serialize(new[] { 11, 14, 17, 19, 20, 24 }) },
        new() { Key = "Referrals", Label = "Referrals", Value = 9, Prior = 7, Note = "Referral channel performing well", Direction = MetricDirection.HigherBetter, SparkJson = JsonSerializer.Serialize(new[] { 3, 4, 5, 6, 7, 9 }) },
    ];

    private static List<DrilldownRow> SeedDrillData() =>
    [
        new() { MetricKey = "Total Live Cases", Ref = "LM1-2026-014", Client = "Marta Silva", Status = "Active", Activity = "2 hours ago", Owner = "N. Foster" },
        new() { MetricKey = "Total Live Cases", Ref = "LM1-2026-031", Client = "Jae Kim", Status = "Active", Activity = "Today", Owner = "L. Hart" },
        new() { MetricKey = "Total Live Cases", Ref = "LM1-2026-044", Client = "Omar Ali", Status = "Active", Activity = "Yesterday", Owner = "A. Collins" },
        new() { MetricKey = "RFEs", Ref = "LM1-2026-052", Client = "Priya Anand", Status = "RFE Open", Activity = "2 days ago", Owner = "A. Collins" },
        new() { MetricKey = "RFEs", Ref = "LM1-2026-061", Client = "Lucas Meyer", Status = "RFE Open", Activity = "1 day ago", Owner = "N. Foster" },
        new() { MetricKey = "Zombie Cases", Ref = "LM1-2026-071", Client = "Sofia Bennett", Status = "Active", Activity = "42 days ago", Owner = "L. Hart" },
        new() { MetricKey = "Zombie Cases", Ref = "LM1-2026-088", Client = "Elena Park", Status = "Active", Activity = "38 days ago", Owner = "M. Cross" },
        new() { MetricKey = "Zombie Cases", Ref = "LM1-2026-091", Client = "Samuel Reed", Status = "Active", Activity = "35 days ago", Owner = "A. Collins" },
        new() { MetricKey = "Refunds", Ref = "LM1-2026-011", Client = "Elena Park", Status = "Refund Requested", Activity = "Today", Owner = "M. Cross" },
        new() { MetricKey = "Refunds", Ref = "LM1-2026-028", Client = "Samuel Reed", Status = "Refund Issued", Activity = "3 days ago", Owner = "A. Collins" },
        new() { MetricKey = "Noise", Ref = "NOISE-204", Client = "Duplicate enquiry", Status = "Tagged noise", Activity = "Today", Owner = "IPC Auto" },
        new() { MetricKey = "Noise", Ref = "NOISE-198", Client = "Spam correspondence", Status = "Tagged noise", Activity = "Yesterday", Owner = "IPC Auto" },
        new() { MetricKey = "Closed This Month", Ref = "LM1-2026-006", Client = "Tariq Hussain", Status = "Closed", Activity = "Today", Owner = "N. Foster" },
        new() { MetricKey = "Closed This Month", Ref = "LM1-2026-018", Client = "Lina Costa", Status = "Closed", Activity = "2 days ago", Owner = "A. Collins" },
        new() { MetricKey = "Leads", Ref = "LEAD-430", Client = "New enquiry", Status = "Open", Activity = "1 hour ago", Owner = "Intake" },
        new() { MetricKey = "Leads", Ref = "LEAD-428", Client = "Website lead", Status = "Open", Activity = "4 hours ago", Owner = "Intake" },
        new() { MetricKey = "Referrals", Ref = "REF-071", Client = "Client referral", Status = "Open", Activity = "Today", Owner = "Intake" },
        new() { MetricKey = "Referrals", Ref = "REF-069", Client = "Partner referral", Status = "Open", Activity = "Yesterday", Owner = "Intake" },
    ];

    private sealed class Scenario(string label, string comparisonLabel, List<ScenarioMetric> metrics, Dictionary<string, List<ScenarioDrill>> drillData)
    {
        public string Label { get; } = label;
        public string ComparisonLabel { get; } = comparisonLabel;
        public List<ScenarioMetric> Metrics { get; } = metrics;
        public Dictionary<string, List<ScenarioDrill>> DrillData { get; } = drillData;
    }

    private sealed record ScenarioMetric(string Key, string Label, int Value, int Prior, string Note, MetricDirection Direction, List<int> Spark, KpiStatus Status)
    {
        public int Value { get; set; } = Value;
        public int Prior { get; set; } = Prior;
        public string Note { get; set; } = Note;
        public List<int> Spark { get; set; } = Spark;
        public KpiStatus Status { get; set; } = Status;
    }

    private sealed record ScenarioDrill(string Ref, string Client, string Status, string Activity, string Owner);
}
