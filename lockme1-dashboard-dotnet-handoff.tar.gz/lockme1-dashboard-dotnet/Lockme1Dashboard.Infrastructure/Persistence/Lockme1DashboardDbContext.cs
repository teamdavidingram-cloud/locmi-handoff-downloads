using Lockme1Dashboard.Domain;
using Microsoft.EntityFrameworkCore;

namespace Lockme1Dashboard.Infrastructure.Persistence;

public class Lockme1DashboardDbContext(DbContextOptions<Lockme1DashboardDbContext> options) : DbContext(options)
{
    public DbSet<DashboardMetric> DashboardMetrics => Set<DashboardMetric>();
    public DbSet<DrilldownRow> DrilldownRows => Set<DrilldownRow>();
    public DbSet<PatchAudit> PatchAudits => Set<PatchAudit>();
    public DbSet<DashboardMeta> DashboardMeta => Set<DashboardMeta>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DashboardMetric>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.HasIndex(x => x.Key).IsUnique();
            entity.Property(x => x.Key).IsRequired();
            entity.Property(x => x.Label).IsRequired();
            entity.Property(x => x.Note).IsRequired();
            entity.Property(x => x.Direction).HasConversion<string>();
            entity.Property(x => x.SparkJson).IsRequired();
        });

        modelBuilder.Entity<DrilldownRow>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.MetricKey).IsRequired();
            entity.Property(x => x.Ref).IsRequired();
            entity.Property(x => x.Client).IsRequired();
            entity.Property(x => x.Status).IsRequired();
            entity.Property(x => x.Activity).IsRequired();
            entity.Property(x => x.Owner).IsRequired();
        });

        modelBuilder.Entity<PatchAudit>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.User).IsRequired();
            entity.Property(x => x.ChangedFields).IsRequired();
            entity.Property(x => x.OldValuesJson).IsRequired();
            entity.Property(x => x.NewValuesJson).IsRequired();
        });

        modelBuilder.Entity<DashboardMeta>(entity =>
        {
            entity.HasKey(x => x.Id);
            entity.Property(x => x.UpdatedBy).IsRequired();
        });
    }
}
