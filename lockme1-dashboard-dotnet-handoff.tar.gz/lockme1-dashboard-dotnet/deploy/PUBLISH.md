# LockMe1 Dashboard .NET Publish & Service Notes

## Publish

From the solution root:

```bash
cd /home/ingramlaw/projects/lock-project/lockme1-dashboard-dotnet
dotnet publish Lockme1Dashboard.Api/Lockme1Dashboard.Api.csproj -c Release
```

Published output appears under:

- `Lockme1Dashboard.Api/bin/Release/net8.0/publish/`

The API project is the main deployment artifact because it is set up to host the dashboard web client.

## Local run

### API host

```bash
cd /home/ingramlaw/projects/lock-project/lockme1-dashboard-dotnet
dotnet run --project Lockme1Dashboard.Api/Lockme1Dashboard.Api.csproj --urls http://127.0.0.1:5210
```

### Optional separate web client during UI work

```bash
cd /home/ingramlaw/projects/lock-project/lockme1-dashboard-dotnet
dotnet run --project Lockme1Dashboard.Web/Lockme1Dashboard.Web.csproj --urls http://127.0.0.1:5211
```

The standalone web client is configured to call the API at `http://127.0.0.1:5210` in development.

## systemd service outline

Sample unit file included:

- `deploy/lockme1-dashboard-dotnet.service`

## Data location

SQLite database is created at:

- `Lockme1Dashboard.Api/App_Data/lockme1-dashboard.db`

Back this up if you want to preserve admin patches and audit history.
