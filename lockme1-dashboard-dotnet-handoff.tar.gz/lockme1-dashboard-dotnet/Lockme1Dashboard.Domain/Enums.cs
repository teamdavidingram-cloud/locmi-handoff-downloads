namespace Lockme1Dashboard.Domain;

public enum Role
{
    Leadership,
    Admin,
    Developer
}

public enum KpiStatus
{
    Green,
    Amber,
    Red
}

public enum MetricDirection
{
    HigherBetter,
    LowerBetter
}

public enum TimeRange
{
    Today,
    Yesterday,
    Last7Days,
    LastMonth
}
