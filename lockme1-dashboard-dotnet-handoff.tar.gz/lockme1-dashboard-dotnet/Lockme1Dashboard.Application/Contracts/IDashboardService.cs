using Lockme1Dashboard.Application.Models;

namespace Lockme1Dashboard.Application.Contracts;

public interface IDashboardService
{
    Task<DashboardResponseDto> GetDashboardAsync(string role, string range);
    Task<DashboardResponseDto> ApplyPatchAsync(string range, PatchRequest request);
    Task<List<AuditRowDto>> GetAuditAsync();
}
