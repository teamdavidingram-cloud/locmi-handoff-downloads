namespace Lockme1Dashboard.Application.Models;

public record AvailableRangeDto(string Key, string Label);
public record PatchMetricDto(string Key, string Label, int Value, int Prior, string Note, string Direction, List<int> Spark);
public record DashboardStateDto(List<PatchMetricDto> Metrics, string UpdatedAt, string UpdatedBy);
public record DrillRowDto(string Ref, string Client, string Status, string Activity, string Owner);
public record SummaryCardDto(string Range, string Label, string ComparisonLabel, string Headline, string Brief, List<string> Bullets, ZombieBreakdownDto ZombieBreakdown, List<string> Drivers);
public record ZombieBreakdownDto(int Active, int NonActive, int Total);
public record MetricDto(string Key, string Label, int Value, int Prior, string Note, string Direction, List<int> Spark, string Status);
public record AnalysisDto(int Score, string Overall, string Brief, List<MetricDto> Metrics, SummaryCardDto Summary);
public record DashboardResponseDto(string Role, string SelectedRange, List<AvailableRangeDto> AvailableRanges, DashboardStateDto PatchState, AnalysisDto Analysis, Dictionary<string, List<DrillRowDto>> DrillData, bool ShowAdminPanel);
public record PatchMetricInput(string Key, int Value);
public record PatchRequest(string User, List<PatchMetricInput> Metrics);
public record AuditRowDto(int Id, string Timestamp, string User, string ChangedFields, string OldValuesJson, string NewValuesJson);
