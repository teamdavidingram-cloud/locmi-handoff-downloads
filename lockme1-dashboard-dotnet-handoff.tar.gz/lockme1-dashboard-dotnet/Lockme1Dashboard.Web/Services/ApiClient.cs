using System.Net.Http.Json;
using Lockme1Dashboard.Web.Models;

namespace Lockme1Dashboard.Web.Services;

public class ApiClient(HttpClient httpClient)
{
    public async Task<DashboardResponse> GetDashboardAsync(string role, string range)
    {
        return (await httpClient.GetFromJsonAsync<DashboardResponse>($"api/dashboard?role={Uri.EscapeDataString(role)}&range={Uri.EscapeDataString(range)}"))!;
    }

    public async Task<DashboardResponse> PatchAsync(string range, PatchRequest request)
    {
        var response = await httpClient.PostAsJsonAsync($"api/admin/patch?range={Uri.EscapeDataString(range)}", request);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<DashboardResponse>())!;
    }

    public async Task<List<AuditRow>> GetAuditAsync()
    {
        return (await httpClient.GetFromJsonAsync<List<AuditRow>>("api/admin/audit"))!;
    }
}
