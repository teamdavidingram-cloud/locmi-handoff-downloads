namespace Lockme1Dashboard.Web.Models;

public class DashboardResponse
{
    public string Role { get; set; } = "leadership";
    public string SelectedRange { get; set; } = "1m";
    public List<AvailableRange> AvailableRanges { get; set; } = [];
    public DashboardPatchState PatchState { get; set; } = new();
    public DashboardAnalysis Analysis { get; set; } = new();
    public Dictionary<string, List<DrillRow>> DrillData { get; set; } = new();
    public bool ShowAdminPanel { get; set; }
}

public class AvailableRange { public string Key { get; set; } = string.Empty; public string Label { get; set; } = string.Empty; }
public class DashboardPatchState { public List<PatchMetric> Metrics { get; set; } = []; public string UpdatedAt { get; set; } = string.Empty; public string UpdatedBy { get; set; } = string.Empty; }
public class PatchMetric { public string Key { get; set; } = string.Empty; public string Label { get; set; } = string.Empty; public int Value { get; set; } public int Prior { get; set; } public string Note { get; set; } = string.Empty; public string Direction { get; set; } = string.Empty; public List<int> Spark { get; set; } = []; }
public class DashboardAnalysis { public int Score { get; set; } public string Overall { get; set; } = string.Empty; public string Brief { get; set; } = string.Empty; public List<Metric> Metrics { get; set; } = []; public DashboardSummary Summary { get; set; } = new(); }
public class Metric { public string Key { get; set; } = string.Empty; public string Label { get; set; } = string.Empty; public int Value { get; set; } public int Prior { get; set; } public string Note { get; set; } = string.Empty; public string Direction { get; set; } = string.Empty; public List<int> Spark { get; set; } = []; public string Status { get; set; } = string.Empty; }
public class DashboardSummary { public string Range { get; set; } = string.Empty; public string Label { get; set; } = string.Empty; public string ComparisonLabel { get; set; } = string.Empty; public string Headline { get; set; } = string.Empty; public string Brief { get; set; } = string.Empty; public List<string> Bullets { get; set; } = []; public ZombieBreakdown ZombieBreakdown { get; set; } = new(); public List<string> Drivers { get; set; } = []; }
public class ZombieBreakdown { public int Active { get; set; } public int NonActive { get; set; } public int Total { get; set; } }
public class DrillRow { public string Ref { get; set; } = string.Empty; public string Client { get; set; } = string.Empty; public string Status { get; set; } = string.Empty; public string Activity { get; set; } = string.Empty; public string Owner { get; set; } = string.Empty; }
public class PatchRequest { public string User { get; set; } = "David Ingram"; public List<PatchMetricInput> Metrics { get; set; } = []; }
public class PatchMetricInput { public string Key { get; set; } = string.Empty; public int Value { get; set; } }
public class AuditRow { public int Id { get; set; } public string Timestamp { get; set; } = string.Empty; public string User { get; set; } = string.Empty; public string ChangedFields { get; set; } = string.Empty; public string OldValuesJson { get; set; } = string.Empty; public string NewValuesJson { get; set; } = string.Empty; }
